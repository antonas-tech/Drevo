# 🌳 Семейное Древо

**Цифровая семейная реликвия** — красивый, современный веб-сайт для хранения истории рода, семейных фотографий, общения и сохранения памяти поколений.

> ⚠️ **ВАЖНО**: Смените пароль администратора (admin/admin) перед публичным развёртыванием!

---

## ✨ Что реализовано

- ✅ **Аутентификация** — регистрация, вход, JWT, rate limiting
- ✅ **RBAC** — роли Guest / User / Moderator / Admin
- ✅ **Интерактивное семейное древо** — SVG с зумом, паном, узлами, связями
- ✅ **Профили членов семьи** — биографии, даты, профессии, награды
- ✅ **Галерея** — masonry-лента, альбомы, лайки/реакции, lightbox, загрузка фото
- ✅ **Чат** — личные диалоги, групповые комнаты, polling-обновление
- ✅ **Раздел «Армия»** — ветераны, истории службы, награды
- ✅ **Летопись рода** — timeline с событиями
- ✅ **События** — семейные праздники и памятные даты
- ✅ **Карта семьи** — города и места рода
- ✅ **Настройки** — тема, уведомления, смена пароля
- ✅ **Админ-панель** — управление пользователями, ролями, блокировками
- ✅ **Dark/Light тема** — переключение в реальном времени
- ✅ **Адаптивный дизайн** — desktop / tablet / mobile
- ✅ **Seed-данные** — 4 поколения семьи, армейские записи, чат, летопись
- ✅ **Docker Compose** — для быстрого запуска

---

## 🚀 Быстрый старт

### Вариант 1: Docker Compose (рекомендуется)

```bash
# 1. Клонировать / распаковать архив
cd family-tree

# 2. Скопировать env
cp .env.example .env

# 3. Запустить всё (PostgreSQL + приложение)
docker-compose up -d

# 4. Запустить миграции и seed
docker-compose exec app npx prisma migrate deploy
docker-compose exec app npm run db:seed

# Открыть: http://localhost:3000
```

### Вариант 2: Локально (без Docker)

#### Требования
- Node.js 18+
- PostgreSQL 14+

```bash
# 1. Установить зависимости
npm install

# 2. Создать базу данных PostgreSQL
psql -U postgres -c "CREATE DATABASE family_tree;"

# 3. Настроить переменные окружения
cp .env.example .env
# Отредактировать .env — вставить DATABASE_URL

# 4. Запустить миграции
npm run db:migrate

# 5. Заполнить тестовыми данными
npm run db:seed

# 6. Запустить dev-сервер
npm run dev

# Открыть: http://localhost:3000
```

---

## 🔐 Тестовые аккаунты

| Роль | Email | Пароль |
|------|-------|--------|
| Admin | admin@family.local | **admin** |
| User | ivan@family.local | password123 |
| User | maria@family.local | password123 |
| Moderator | mod@family.local | password123 |

> Также можно войти по username: `admin` / `admin`

---

## 🗄️ Переменные окружения

```env
# Обязательные
DATABASE_URL="postgresql://postgres:postgres@localhost:5432/family_tree"
NEXTAUTH_URL="http://localhost:3000"
NEXTAUTH_SECRET="min-32-chars-change-in-production"
JWT_SECRET="change-in-production"

# Опциональные
UPLOAD_DIR="./public/uploads"  # Папка для загружаемых файлов
MAX_FILE_SIZE=10485760          # 10 MB
```

---

## 📁 Структура проекта

```
family-tree/
├── prisma/
│   ├── schema.prisma     # Схема БД (17 моделей)
│   └── seed.ts           # Тестовые данные
├── src/
│   ├── app/
│   │   ├── api/          # REST API endpoints
│   │   │   ├── auth/     # login, register, change-password
│   │   │   ├── family/   # members, relations
│   │   │   ├── gallery/  # photos, albums, upload, reactions
│   │   │   ├── chat/     # chats, messages
│   │   │   ├── army/     # army records
│   │   │   ├── events/   # family events
│   │   │   ├── chronicle/# chronicles
│   │   │   ├── users/    # user search
│   │   │   ├── notifications/
│   │   │   └── admin/    # user management
│   │   ├── tree/         # Семейное древо
│   │   ├── gallery/      # Галерея
│   │   ├── chat/         # Чат
│   │   ├── army/         # Армия
│   │   ├── events/       # События
│   │   ├── chronicle/    # Летопись
│   │   ├── map/          # Карта
│   │   ├── settings/     # Настройки
│   │   ├── admin/        # Админ-панель
│   │   ├── login/        # Авторизация
│   │   └── register/     # Регистрация
│   ├── components/
│   │   ├── header.tsx    # Навигация
│   │   ├── providers.tsx # Auth + Theme провайдеры
│   │   └── ui/           # UI компоненты
│   └── lib/
│       ├── prisma.ts     # Prisma клиент
│       ├── auth.ts       # JWT утилиты
│       ├── api.ts        # API хелперы
│       └── utils.ts      # Утилиты
├── docker-compose.yml
├── Dockerfile
├── .env.example
└── README.md
```

---

## 🛠️ Команды

```bash
npm run dev          # Запуск dev-сервера (localhost:3000)
npm run build        # Сборка для production
npm run start        # Запуск production-сервера
npm run lint         # Проверка кода
npm run test         # Запуск тестов
npm run db:migrate   # Применить миграции
npm run db:seed      # Заполнить тестовыми данными
npm run db:studio    # Открыть Prisma Studio (GUI для БД)
npm run db:reset     # Сбросить БД и пересоздать (ОСТОРОЖНО!)
```

---

## 🗃️ База данных

Основные модели:
- `User` — аккаунты пользователей (RBAC: GUEST / USER / MODERATOR / ADMIN)
- `Profile` — профили пользователей
- `FamilyMember` — члены семьи (биография, даты, координаты в дереве)
- `FamilyRelation` — связи (PARENT_CHILD / SPOUSE / SIBLING)
- `Photo` + `Album` — фотогалерея
- `Chat` + `ChatMember` + `Message` — мессенджер
- `ArmyRecord` — военная служба
- `FamilyEvent` — события
- `Chronicle` — летопись
- `Notification` — уведомления
- `ModerationLog` + `AuditLog` — логи

---

## 🔒 Безопасность

- Пароли хешируются через bcrypt (cost 12)
- JWT-токены (7 дней)
- Rate limiting на /api/auth/login (5 попыток/минуту)
- Валидация через Zod
- Ограничения загрузки файлов (тип + размер)
- RBAC на всех защищённых эндпоинтах

---

## ❓ FAQ

**Как добавить члена семьи?**
Войдите в аккаунт → раздел «Древо» → кнопка «Добавить».

**Как стать администратором?**
Войдите как `admin` / `admin` → Настройки → роли пользователей.

**Где хранятся загруженные фото?**
В папке `public/uploads/`. Для production используйте S3.

**Как запустить только БД через Docker?**
```bash
docker-compose up postgres -d
```

**Ошибка подключения к БД?**
Проверьте `DATABASE_URL` в `.env`. PostgreSQL должен быть запущен.

---

## 📈 Что можно улучшить

1. Realtime через WebSocket (Socket.IO) вместо polling
2. Хранение фото в S3/Cloudflare R2
3. Push-уведомления (Web Push API)
4. Полнотекстовый поиск через PostgreSQL FTS
5. Экспорт в PDF «Книга рода»
6. Импорт GEDCOM (стандарт генеалогии)
7. Голосовые заметки
8. E2E тесты (Playwright)
9. Оптимизация изображений (Sharp)
10. Кеширование через Redis

---

Создано с ❤️ — цифровая память для будущих поколений.
