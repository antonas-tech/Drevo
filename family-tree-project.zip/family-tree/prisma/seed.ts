import { PrismaClient, Role, Gender, RelationType } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Seeding database...')

  // Create users
  const adminHash = await bcrypt.hash('admin', 12)
  const userHash = await bcrypt.hash('password123', 12)

  const admin = await prisma.user.upsert({
    where: { email: 'admin@family.local' },
    update: {},
    create: {
      email: 'admin@family.local',
      username: 'admin',
      passwordHash: adminHash,
      role: Role.ADMIN,
      profile: {
        create: {
          bio: 'Администратор семейного сайта',
          isPublic: true,
        }
      }
    }
  })

  const user1 = await prisma.user.upsert({
    where: { email: 'ivan@family.local' },
    update: {},
    create: {
      email: 'ivan@family.local',
      username: 'ivan_ivanov',
      passwordHash: userHash,
      role: Role.USER,
      profile: {
        create: {
          bio: 'Люблю семейные встречи и историю рода',
          location: 'Москва',
          isPublic: true,
        }
      }
    }
  })

  const user2 = await prisma.user.upsert({
    where: { email: 'maria@family.local' },
    update: {},
    create: {
      email: 'maria@family.local',
      username: 'maria_ivanova',
      passwordHash: userHash,
      role: Role.USER,
      profile: {
        create: {
          bio: 'Хранительница семейных традиций',
          location: 'Санкт-Петербург',
          isPublic: true,
        }
      }
    }
  })

  const mod = await prisma.user.upsert({
    where: { email: 'mod@family.local' },
    update: {},
    create: {
      email: 'mod@family.local',
      username: 'moderator',
      passwordHash: userHash,
      role: Role.MODERATOR,
      profile: {
        create: {
          isPublic: true,
        }
      }
    }
  })

  console.log('✅ Users created')

  // Create family tree members
  const great_grandfather = await prisma.familyMember.upsert({
    where: { id: 'member-gg-1' },
    update: {},
    create: {
      id: 'member-gg-1',
      firstName: 'Николай',
      lastName: 'Иванов',
      middleName: 'Петрович',
      gender: Gender.MALE,
      birthDate: new Date('1895-03-15'),
      deathDate: new Date('1971-11-20'),
      birthPlace: 'Тула, Россия',
      biography: 'Прапрадед. Участник двух мировых войн. Работал на заводе, был уважаемым человеком в посёлке.',
      isAlive: false,
      profession: 'Токарь',
      awards: ['Орден Красной Звезды', 'Медаль «За победу над Германией»'],
      cities: ['Тула', 'Москва'],
      generation: 1,
      posX: 500,
      posY: 100,
    }
  })

  const great_grandmother = await prisma.familyMember.upsert({
    where: { id: 'member-gg-2' },
    update: {},
    create: {
      id: 'member-gg-2',
      firstName: 'Анна',
      lastName: 'Иванова',
      maidenName: 'Соколова',
      middleName: 'Васильевна',
      gender: Gender.FEMALE,
      birthDate: new Date('1898-07-22'),
      deathDate: new Date('1978-04-10'),
      birthPlace: 'Тула, Россия',
      biography: 'Прапрабабушка. Воспитала пятерых детей в тяжелые годы войны.',
      isAlive: false,
      profession: 'Домохозяйка, учительница',
      cities: ['Тула', 'Москва'],
      generation: 1,
      posX: 700,
      posY: 100,
    }
  })

  const grandfather = await prisma.familyMember.upsert({
    where: { id: 'member-gf-1' },
    update: {},
    create: {
      id: 'member-gf-1',
      firstName: 'Алексей',
      lastName: 'Иванов',
      middleName: 'Николаевич',
      gender: Gender.MALE,
      birthDate: new Date('1925-06-10'),
      deathDate: new Date('2005-09-03'),
      birthPlace: 'Тула, Россия',
      biography: 'Дед. Инженер-механик. Построил дачу своими руками. Очень любил рыбалку и шахматы.',
      isAlive: false,
      profession: 'Инженер-механик',
      awards: ['Медаль «Ветеран труда»'],
      cities: ['Тула', 'Москва', 'Подмосковье'],
      generation: 2,
      posX: 400,
      posY: 250,
    }
  })

  const grandmother = await prisma.familyMember.upsert({
    where: { id: 'member-gm-1' },
    update: {},
    create: {
      id: 'member-gm-1',
      firstName: 'Людмила',
      lastName: 'Иванова',
      maidenName: 'Кузнецова',
      middleName: 'Сергеевна',
      gender: Gender.FEMALE,
      birthDate: new Date('1928-12-05'),
      deathDate: new Date('2010-02-14'),
      birthPlace: 'Рязань, Россия',
      biography: 'Бабушка. Врач-педиатр. Работала в детской больнице 40 лет. Вырастила прекрасных детей.',
      isAlive: false,
      profession: 'Врач-педиатр',
      cities: ['Рязань', 'Москва'],
      generation: 2,
      posX: 600,
      posY: 250,
    }
  })

  const father = await prisma.familyMember.upsert({
    where: { id: 'member-f-1' },
    update: {},
    create: {
      id: 'member-f-1',
      firstName: 'Сергей',
      lastName: 'Иванов',
      middleName: 'Алексеевич',
      gender: Gender.MALE,
      birthDate: new Date('1958-03-20'),
      birthPlace: 'Москва, Россия',
      biography: 'Папа. Программист, один из первых в стране. Любит классическую музыку и туризм.',
      isAlive: true,
      profession: 'Программист',
      cities: ['Москва', 'Подмосковье'],
      generation: 3,
      posX: 350,
      posY: 400,
    }
  })

  const mother = await prisma.familyMember.upsert({
    where: { id: 'member-m-1' },
    update: {},
    create: {
      id: 'member-m-1',
      firstName: 'Елена',
      lastName: 'Иванова',
      maidenName: 'Петрова',
      middleName: 'Михайловна',
      gender: Gender.FEMALE,
      birthDate: new Date('1962-08-15'),
      birthPlace: 'Ленинград, СССР',
      biography: 'Мама. Преподаватель математики. Кандидат наук.',
      isAlive: true,
      profession: 'Преподаватель математики',
      cities: ['Ленинград', 'Москва'],
      generation: 3,
      posX: 550,
      posY: 400,
    }
  })

  const me = await prisma.familyMember.upsert({
    where: { id: 'member-me-1' },
    update: {},
    create: {
      id: 'member-me-1',
      firstName: 'Иван',
      lastName: 'Иванов',
      middleName: 'Сергеевич',
      gender: Gender.MALE,
      birthDate: new Date('1988-05-12'),
      birthPlace: 'Москва, Россия',
      biography: 'Создатель этого семейного архива. Люблю технологии и историю семьи.',
      isAlive: true,
      profession: 'Разработчик ПО',
      cities: ['Москва'],
      generation: 4,
      posX: 450,
      posY: 550,
      userId: user1.id,
    }
  })

  const sister = await prisma.familyMember.upsert({
    where: { id: 'member-sis-1' },
    update: {},
    create: {
      id: 'member-sis-1',
      firstName: 'Мария',
      lastName: 'Иванова',
      middleName: 'Сергеевна',
      gender: Gender.FEMALE,
      birthDate: new Date('1991-11-30'),
      birthPlace: 'Москва, Россия',
      biography: 'Сестра. Дизайнер интерьеров.',
      isAlive: true,
      profession: 'Дизайнер интерьеров',
      cities: ['Москва', 'Санкт-Петербург'],
      generation: 4,
      posX: 650,
      posY: 550,
      userId: user2.id,
    }
  })

  console.log('✅ Family members created')

  // Create relations
  await prisma.familyRelation.createMany({
    skipDuplicates: true,
    data: [
      // great-grandparents marriage
      { memberAId: great_grandfather.id, memberBId: great_grandmother.id, type: RelationType.SPOUSE },
      // grandparents parents
      { memberAId: great_grandfather.id, memberBId: grandfather.id, type: RelationType.PARENT_CHILD },
      { memberAId: great_grandmother.id, memberBId: grandfather.id, type: RelationType.PARENT_CHILD },
      // grandparents marriage
      { memberAId: grandfather.id, memberBId: grandmother.id, type: RelationType.SPOUSE },
      // parents parents
      { memberAId: grandfather.id, memberBId: father.id, type: RelationType.PARENT_CHILD },
      { memberAId: grandmother.id, memberBId: father.id, type: RelationType.PARENT_CHILD },
      // parents marriage
      { memberAId: father.id, memberBId: mother.id, type: RelationType.SPOUSE },
      // children
      { memberAId: father.id, memberBId: me.id, type: RelationType.PARENT_CHILD },
      { memberAId: mother.id, memberBId: me.id, type: RelationType.PARENT_CHILD },
      { memberAId: father.id, memberBId: sister.id, type: RelationType.PARENT_CHILD },
      { memberAId: mother.id, memberBId: sister.id, type: RelationType.PARENT_CHILD },
      // siblings
      { memberAId: me.id, memberBId: sister.id, type: RelationType.SIBLING },
    ]
  })

  console.log('✅ Relations created')

  // Create army record
  await prisma.armyRecord.upsert({
    where: { familyMemberId: great_grandfather.id },
    update: {},
    create: {
      familyMemberId: great_grandfather.id,
      branch: 'Пехота',
      rank: 'Старший сержант',
      startYear: 1914,
      endYear: 1945,
      location: 'Восточный фронт, Польша, Германия',
      unit: '112-я стрелковая дивизия',
      story: 'Николай Петрович прошёл две войны. В Первую мировую был ранен под Варшавой. В Великую Отечественную воевал с первых дней, дошёл до Берлина. Говорил мало, но его глаза хранили память о тех страшных годах.',
      achievements: ['Орден Красной Звезды', 'Медаль «За отвагу»', 'Медаль «За победу над Германией»'],
      isVeteran: true,
    }
  })

  await prisma.armyRecord.upsert({
    where: { familyMemberId: grandfather.id },
    update: {},
    create: {
      familyMemberId: grandfather.id,
      branch: 'Инженерные войска',
      rank: 'Лейтенант',
      startYear: 1943,
      endYear: 1945,
      location: 'Украина, Румыния',
      unit: '5-й инженерно-сапёрный батальон',
      story: 'Алексей Николаевич служил сапёром. Разминировал дороги и мосты. После войны применил знания инженера на мирном поприще.',
      achievements: ['Медаль «За боевые заслуги»', 'Медаль «Ветеран труда»'],
      isVeteran: true,
    }
  })

  console.log('✅ Army records created')

  // Create albums
  const album1 = await prisma.album.upsert({
    where: { id: 'album-1' },
    update: {},
    create: {
      id: 'album-1',
      name: 'Архив',
      description: 'Старые семейные фотографии',
      isPublic: true,
    }
  })

  const album2 = await prisma.album.upsert({
    where: { id: 'album-2' },
    update: {},
    create: {
      id: 'album-2',
      name: 'Путешествия',
      description: 'Семейные поездки и отдых',
      isPublic: true,
    }
  })

  const album3 = await prisma.album.upsert({
    where: { id: 'album-3' },
    update: {},
    create: {
      id: 'album-3',
      name: 'Детство',
      description: 'Детские фотографии',
      isPublic: true,
    }
  })

  console.log('✅ Albums created')

  // Create events
  await prisma.familyEvent.createMany({
    skipDuplicates: true,
    data: [
      {
        title: 'Новый год 2024',
        description: 'Семейное собрание на Новый год',
        date: new Date('2024-01-01'),
        location: 'Москва',
        type: 'event',
      },
      {
        title: 'День рождения дедушки',
        description: 'Юбилей деда — 95 лет',
        date: new Date('2020-06-10'),
        location: 'Москва',
        type: 'birthday',
      },
    ]
  })

  // Create chronicle entries
  await prisma.chronicle.createMany({
    skipDuplicates: true,
    data: [
      {
        title: 'Основание семьи Ивановых',
        content: 'Семья Ивановых берёт своё начало в небольшом городе Тула. Первые документально подтверждённые упоминания относятся к концу XIX века, когда прапрадед Николай Петрович Иванов работал на оружейном заводе.',
        year: 1895,
        tags: ['история', 'происхождение'],
        author: 'Иван Иванов',
        isPublic: true,
      },
      {
        title: 'Семья в годы Великой Отечественной',
        content: 'В 1941 году семью разлучила война. Николай Петрович ушёл на фронт в первые дни. Анна Васильевна осталась с детьми. Несмотря на все трудности, семья сохранилась и воссоединилась в 1945 году.',
        year: 1941,
        tags: ['война', 'история'],
        author: 'Иван Иванов',
        isPublic: true,
      },
      {
        title: 'Переезд в Москву',
        content: 'В 1955 году семья перебралась в Москву. Алексей Николаевич получил квартиру как ветеран и передовой работник. Начался новый этап жизни рода.',
        year: 1955,
        tags: ['переезд', 'Москва'],
        author: 'Иван Иванов',
        isPublic: true,
      },
    ]
  })

  console.log('✅ Events and chronicles created')

  // Create group chat
  const familyChat = await prisma.chat.upsert({
    where: { id: 'chat-family-1' },
    update: {},
    create: {
      id: 'chat-family-1',
      name: 'Семья Ивановых 🏠',
      isGroup: true,
      description: 'Общий чат семьи',
    }
  })

  // Add members to chat
  await prisma.chatMember.createMany({
    skipDuplicates: true,
    data: [
      { chatId: familyChat.id, userId: admin.id, role: 'admin' },
      { chatId: familyChat.id, userId: user1.id, role: 'member' },
      { chatId: familyChat.id, userId: user2.id, role: 'member' },
    ]
  })

  // Add seed messages
  await prisma.message.createMany({
    data: [
      {
        chatId: familyChat.id,
        senderId: admin.id,
        content: 'Добро пожаловать в семейный чат! 🎉',
        type: 'TEXT',
      },
      {
        chatId: familyChat.id,
        senderId: user1.id,
        content: 'Отлично! Наконец-то есть место, где вся семья собирается вместе 😊',
        type: 'TEXT',
      },
      {
        chatId: familyChat.id,
        senderId: user2.id,
        content: 'Какой красивый сайт! Надо будет добавить больше старых фотографий из архива',
        type: 'TEXT',
      },
    ]
  })

  console.log('✅ Chats and messages created')

  // Notifications
  await prisma.notification.createMany({
    data: [
      {
        userId: user1.id,
        type: 'BIRTHDAY',
        title: 'День рождения!',
        body: 'Сегодня день рождения Елены Ивановой',
        isRead: false,
      },
      {
        userId: user1.id,
        type: 'NEW_PHOTO',
        title: 'Новые фото',
        body: 'Добавлены новые фотографии в альбом «Архив»',
        isRead: false,
      },
    ]
  })

  console.log('✅ Notifications created')
  console.log('🎉 Seeding complete!')
  console.log('')
  console.log('Test accounts:')
  console.log('  Admin:     admin@family.local / admin')
  console.log('  User 1:    ivan@family.local / password123')
  console.log('  User 2:    maria@family.local / password123')
  console.log('  Moderator: mod@family.local / password123')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
