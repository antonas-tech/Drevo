/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ['class'],
  content: [
    './pages/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './app/**/*.{ts,tsx}',
    './src/**/*.{ts,tsx}',
  ],
  theme: {
    container: {
      center: true,
      padding: '2rem',
      screens: {
        '2xl': '1400px',
      },
    },
    extend: {
      colors: {
        // Warm family palette
        parchment: {
          50: '#fefdf8',
          100: '#fdf9ec',
          200: '#faf0cc',
          300: '#f5e29e',
          400: '#eecf6b',
          500: '#e5b83a',
          600: '#c99820',
          700: '#a67a18',
          800: '#896119',
          900: '#71501a',
        },
        mahogany: {
          50: '#fdf4f2',
          100: '#fce8e3',
          200: '#fad4ca',
          300: '#f5b0a0',
          400: '#ed8169',
          500: '#e15e42',
          600: '#cc4228',
          700: '#ab361e',
          800: '#8d2f1c',
          900: '#762d1d',
        },
        forest: {
          50: '#f0f7f4',
          100: '#dcede5',
          200: '#bbdacc',
          300: '#8dbfac',
          400: '#5b9f86',
          500: '#3d836c',
          600: '#2e6857',
          700: '#265447',
          800: '#21433a',
          900: '#1d3830',
        },
        // Accent for tree glow
        glow: {
          gold: '#f5c842',
          amber: '#f59e0b',
          warm: '#fbbf24',
        },
        border: 'hsl(var(--border))',
        input: 'hsl(var(--input))',
        ring: 'hsl(var(--ring))',
        background: 'hsl(var(--background))',
        foreground: 'hsl(var(--foreground))',
        primary: {
          DEFAULT: 'hsl(var(--primary))',
          foreground: 'hsl(var(--primary-foreground))',
        },
        secondary: {
          DEFAULT: 'hsl(var(--secondary))',
          foreground: 'hsl(var(--secondary-foreground))',
        },
        destructive: {
          DEFAULT: 'hsl(var(--destructive))',
          foreground: 'hsl(var(--destructive-foreground))',
        },
        muted: {
          DEFAULT: 'hsl(var(--muted))',
          foreground: 'hsl(var(--muted-foreground))',
        },
        accent: {
          DEFAULT: 'hsl(var(--accent))',
          foreground: 'hsl(var(--accent-foreground))',
        },
        popover: {
          DEFAULT: 'hsl(var(--popover))',
          foreground: 'hsl(var(--popover-foreground))',
        },
        card: {
          DEFAULT: 'hsl(var(--card))',
          foreground: 'hsl(var(--card-foreground))',
        },
      },
      fontFamily: {
        serif: ['Playfair Display', 'Georgia', 'serif'],
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['Playfair Display', 'serif'],
      },
      borderRadius: {
        lg: 'var(--radius)',
        md: 'calc(var(--radius) - 2px)',
        sm: 'calc(var(--radius) - 4px)',
      },
      keyframes: {
        'accordion-down': {
          from: { height: 0 },
          to: { height: 'var(--radix-accordion-content-height)' },
        },
        'accordion-up': {
          from: { height: 'var(--radix-accordion-content-height)' },
          to: { height: 0 },
        },
        'glow-pulse': {
          '0%, 100%': { boxShadow: '0 0 5px 2px rgba(245,200,66,0.4)' },
          '50%': { boxShadow: '0 0 20px 8px rgba(245,200,66,0.8)' },
        },
        'branch-grow': {
          from: { strokeDashoffset: '1000' },
          to: { strokeDashoffset: '0' },
        },
        'float': {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-8px)' },
        },
        'shimmer': {
          from: { backgroundPosition: '0 0' },
          to: { backgroundPosition: '-200% 0' },
        },
        'fade-in-up': {
          from: { opacity: '0', transform: 'translateY(20px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
      },
      animation: {
        'accordion-down': 'accordion-down 0.2s ease-out',
        'accordion-up': 'accordion-up 0.2s ease-out',
        'glow-pulse': 'glow-pulse 2s ease-in-out infinite',
        'branch-grow': 'branch-grow 1.5s ease-out forwards',
        'float': 'float 3s ease-in-out infinite',
        'shimmer': 'shimmer 2s linear infinite',
        'fade-in-up': 'fade-in-up 0.5s ease-out forwards',
      },
      backgroundImage: {
        'paper-texture': "url('/textures/paper.png')",
        'tree-gradient': 'radial-gradient(ellipse at bottom, #1a2e1a 0%, #0d1a0d 100%)',
      },
    },
  },
  plugins: [require('tailwindcss-animate')],
}
