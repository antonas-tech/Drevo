'use client'

import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Header } from '@/components/header'
import { formatYear, cn } from '@/lib/utils'
import { Shield, Star, MapPin, Calendar, Users, Sword, Loader2, ChevronDown, ChevronUp } from 'lucide-react'

interface ArmyRecord {
  id: string
  branch?: string | null
  rank?: string | null
  startYear?: number | null
  endYear?: number | null
  location?: string | null
  unit?: string | null
  story?: string | null
  achievements: string[]
  isVeteran: boolean
  familyMember: {
    id: string
    firstName: string
    lastName: string
    middleName?: string | null
    birthDate?: string | null
    deathDate?: string | null
    photo?: string | null
    isAlive: boolean
  }
}

export default function ArmyPage() {
  const [records, setRecords] = useState<ArmyRecord[]>([])
  const [loading, setLoading] = useState(true)
  const [expandedId, setExpandedId] = useState<string | null>(null)

  useEffect(() => {
    fetch('/api/army')
      .then(r => r.json())
      .then(d => { if (d.success) setRecords(d.data) })
      .finally(() => setLoading(false))
  }, [])

  const veterans = records.filter(r => r.isVeteran)
  const nonVeterans = records.filter(r => !r.isVeteran)

  return (
    <div className="min-h-screen">
      <Header />

      {/* Hero */}
      <div className="relative bg-gradient-to-br from-amber-950 to-slate-900 text-white py-16 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{
            backgroundImage: `repeating-linear-gradient(45deg, #ffffff 0, #ffffff 1px, transparent 0, transparent 50%)`,
            backgroundSize: '20px 20px'
          }} />
        </div>
        <div className="container relative text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <div className="flex justify-center mb-4">
              <div className="p-4 rounded-full bg-amber-500/20 border border-amber-500/30">
                <Shield className="w-10 h-10 text-amber-400" />
              </div>
            </div>
            <h1 className="font-display text-4xl sm:text-5xl font-bold mb-4">Воинская Слава</h1>
            <p className="text-amber-200/70 text-lg max-w-xl mx-auto">
              Память о тех, кто защищал Родину. Их подвиги и истории хранятся в сердцах семьи навечно.
            </p>
            <div className="flex items-center justify-center gap-8 mt-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-amber-400">{records.length}</div>
                <div className="text-sm text-amber-200/60">Служивших</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-amber-400">{veterans.length}</div>
                <div className="text-sm text-amber-200/60">Ветеранов</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-amber-400">
                  {records.reduce((acc, r) => acc + r.achievements.length, 0)}
                </div>
                <div className="text-sm text-amber-200/60">Наград</div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      <div className="container py-12">
        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : records.length === 0 ? (
          <div className="text-center py-20 text-muted-foreground">
            <Shield className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p>Нет записей о военной службе</p>
          </div>
        ) : (
          <>
            {/* Veterans section */}
            {veterans.length > 0 && (
              <div className="mb-12">
                <h2 className="section-header mb-6 flex items-center gap-2">
                  <Star className="w-6 h-6 text-amber-500" />
                  Ветераны
                </h2>
                <div className="space-y-4">
                  {veterans.map((record, i) => (
                    <ArmyCard
                      key={record.id}
                      record={record}
                      index={i}
                      isExpanded={expandedId === record.id}
                      onToggle={() => setExpandedId(expandedId === record.id ? null : record.id)}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Other service */}
            {nonVeterans.length > 0 && (
              <div>
                <h2 className="section-header mb-6 flex items-center gap-2">
                  <Sword className="w-6 h-6 text-muted-foreground" />
                  Служили Родине
                </h2>
                <div className="space-y-4">
                  {nonVeterans.map((record, i) => (
                    <ArmyCard
                      key={record.id}
                      record={record}
                      index={i}
                      isExpanded={expandedId === record.id}
                      onToggle={() => setExpandedId(expandedId === record.id ? null : record.id)}
                    />
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}

function ArmyCard({
  record,
  index,
  isExpanded,
  onToggle,
}: {
  record: ArmyRecord
  index: number
  isExpanded: boolean
  onToggle: () => void
}) {
  const m = record.familyMember

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.1 }}
      className={cn(
        'card-premium overflow-hidden',
        record.isVeteran && 'border-amber-500/30'
      )}
    >
      <button
        onClick={onToggle}
        className="w-full flex items-center gap-4 p-5 text-left hover:bg-accent/30 transition-colors"
      >
        {/* Avatar */}
        <div className={cn(
          'w-14 h-14 rounded-full flex items-center justify-center text-white font-bold text-lg flex-shrink-0',
          record.isVeteran ? 'bg-amber-600' : 'bg-slate-600'
        )}>
          {m.firstName[0]}{m.lastName[0]}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-0.5">
            <h3 className="font-display text-lg font-semibold">
              {m.lastName} {m.firstName} {m.middleName}
            </h3>
            {record.isVeteran && (
              <span className="px-2 py-0.5 bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 rounded text-xs font-medium">
                Ветеран
              </span>
            )}
          </div>
          <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground">
            {record.branch && (
              <span className="flex items-center gap-1">
                <Shield className="w-3.5 h-3.5" />
                {record.branch}
              </span>
            )}
            {record.rank && <span className="font-medium text-foreground">{record.rank}</span>}
            {(record.startYear || record.endYear) && (
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                {record.startYear}–{record.endYear || 'н.в.'}
              </span>
            )}
            {record.location && (
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5" />
                {record.location}
              </span>
            )}
          </div>
        </div>

        <div className="flex-shrink-0 text-muted-foreground">
          {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
        </div>
      </button>

      {/* Expanded content */}
      {isExpanded && (
        <motion.div
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: 'auto', opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="border-t border-border px-5 pb-5"
        >
          <div className="pt-4 space-y-4">
            {/* Timeline */}
            {record.unit && (
              <div className="flex items-start gap-3">
                <Users className="w-4 h-4 text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-xs text-muted-foreground">Воинская часть</p>
                  <p className="text-sm font-medium">{record.unit}</p>
                </div>
              </div>
            )}

            {/* Story */}
            {record.story && (
              <div>
                <h4 className="font-medium text-sm mb-2">История службы</h4>
                <blockquote className="border-l-2 border-amber-500 pl-4 text-sm text-muted-foreground leading-relaxed italic">
                  {record.story}
                </blockquote>
              </div>
            )}

            {/* Achievements */}
            {record.achievements.length > 0 && (
              <div>
                <h4 className="font-medium text-sm mb-2 flex items-center gap-1.5">
                  <Star className="w-4 h-4 text-amber-500" />
                  Награды и достижения
                </h4>
                <div className="flex flex-wrap gap-2">
                  {record.achievements.map((ach, i) => (
                    <span
                      key={i}
                      className="px-3 py-1 rounded-full bg-amber-100 dark:bg-amber-900/20 text-amber-700 dark:text-amber-300 text-xs font-medium border border-amber-200 dark:border-amber-800"
                    >
                      🏅 {ach}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </motion.div>
      )}
    </motion.div>
  )
}
