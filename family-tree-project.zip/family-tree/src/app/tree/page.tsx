'use client'

import { useEffect, useRef, useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Header } from '@/components/header'
import { useAuth } from '@/components/providers'
import { formatYear, getAge, formatDate, cn } from '@/lib/utils'
import {
  TreePine, Search, Plus, X, ZoomIn, ZoomOut, Maximize2,
  User, Calendar, MapPin, Briefcase, Star, Filter, Loader2
} from 'lucide-react'

interface FamilyMember {
  id: string
  firstName: string
  lastName: string
  maidenName?: string | null
  middleName?: string | null
  gender: string
  birthDate?: string | null
  deathDate?: string | null
  birthPlace?: string | null
  biography?: string | null
  profession?: string | null
  photo?: string | null
  isAlive: boolean
  isMemorial: boolean
  generation?: number | null
  posX?: number | null
  posY?: number | null
  awards: string[]
  relationsA: Array<{ type: string; memberB: FamilyMember }>
  relationsB: Array<{ type: string; memberA: FamilyMember }>
}

const GENDER_COLORS = {
  MALE: '#5b9f86',
  FEMALE: '#cc4228',
  OTHER: '#7c3aed',
  UNKNOWN: '#6b7280',
}

export default function TreePage() {
  const { user } = useAuth()
  const svgRef = useRef<SVGSVGElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const [members, setMembers] = useState<FamilyMember[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedMember, setSelectedMember] = useState<FamilyMember | null>(null)
  const [searchQuery, setSearchQuery] = useState('')
  const [filter, setFilter] = useState<'all' | 'alive' | 'deceased'>('all')
  const [viewBox, setViewBox] = useState({ x: 0, y: 0, w: 1200, h: 800 })
  const isDragging = useRef(false)
  const dragStart = useRef({ x: 0, y: 0, vbX: 0, vbY: 0 })
  const [showAddModal, setShowAddModal] = useState(false)
  const [newMember, setNewMember] = useState({
    firstName: '', lastName: '', gender: 'UNKNOWN',
    birthDate: '', isAlive: true, profession: ''
  })

  useEffect(() => {
    fetch('/api/family/members')
      .then(r => r.json())
      .then(d => {
        if (d.success) setMembers(d.data)
      })
      .finally(() => setLoading(false))
  }, [])

  const filteredMembers = members.filter(m => {
    const matchSearch = !searchQuery || [m.firstName, m.lastName, m.middleName].join(' ').toLowerCase().includes(searchQuery.toLowerCase())
    const matchFilter = filter === 'all' || (filter === 'alive' ? m.isAlive : !m.isAlive)
    return matchSearch && matchFilter
  })

  // Build edges
  const edges: Array<{ x1: number; y1: number; x2: number; y2: number; type: string }> = []

  filteredMembers.forEach(m => {
    const x1 = m.posX || 0
    const y1 = m.posY || 0
    m.relationsA?.forEach(rel => {
      const target = filteredMembers.find(fm => fm.id === rel.memberB.id)
      if (target) {
        edges.push({ x1, y1, x2: target.posX || 0, y2: target.posY || 0, type: rel.type })
      }
    })
  })

  const handleMouseDown = (e: React.MouseEvent) => {
    if ((e.target as SVGElement).tagName === 'circle' || (e.target as SVGElement).closest('.tree-node-group')) return
    isDragging.current = true
    dragStart.current = { x: e.clientX, y: e.clientY, vbX: viewBox.x, vbY: viewBox.y }
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging.current) return
    const dx = (e.clientX - dragStart.current.x)
    const dy = (e.clientY - dragStart.current.y)
    const scale = viewBox.w / (containerRef.current?.clientWidth || 1200)
    setViewBox(v => ({ ...v, x: dragStart.current.vbX - dx * scale, y: dragStart.current.vbY - dy * scale }))
  }

  const handleMouseUp = () => { isDragging.current = false }

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault()
    const factor = e.deltaY > 0 ? 1.15 : 0.87
    setViewBox(v => {
      const newW = Math.max(400, Math.min(3000, v.w * factor))
      const newH = newW * 0.67
      return { ...v, w: newW, h: newH }
    })
  }

  const zoom = (direction: 'in' | 'out') => {
    const factor = direction === 'in' ? 0.85 : 1.2
    setViewBox(v => {
      const newW = Math.max(400, Math.min(3000, v.w * factor))
      const newH = newW * 0.67
      return { ...v, w: newW, h: newH }
    })
  }

  const resetView = () => setViewBox({ x: 0, y: 0, w: 1200, h: 800 })

  const handleAddMember = async () => {
    if (!newMember.firstName || !newMember.lastName) return
    const token = localStorage.getItem('auth-token')
    const res = await fetch('/api/family/members', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({
        ...newMember,
        posX: 300 + Math.random() * 400,
        posY: 400 + Math.random() * 200,
        generation: 4,
      })
    })
    const data = await res.json()
    if (data.success) {
      setMembers(prev => [...prev, data.data])
      setShowAddModal(false)
      setNewMember({ firstName: '', lastName: '', gender: 'UNKNOWN', birthDate: '', isAlive: true, profession: '' })
    }
  }

  return (
    <div className="h-screen flex flex-col overflow-hidden">
      <Header />

      {/* Toolbar */}
      <div className="flex items-center gap-3 px-4 py-2 border-b border-border bg-background/80 backdrop-blur-sm flex-shrink-0">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Поиск по имени..."
            className="w-full pl-9 pr-4 py-1.5 text-sm rounded-lg border border-input bg-background focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        <div className="flex rounded-lg border border-border overflow-hidden text-sm">
          {(['all', 'alive', 'deceased'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                'px-3 py-1.5 transition-colors',
                filter === f ? 'bg-primary text-primary-foreground' : 'hover:bg-accent/50'
              )}
            >
              {f === 'all' ? 'Все' : f === 'alive' ? 'Живые' : 'Ушедшие'}
            </button>
          ))}
        </div>

        {user && (
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Добавить
          </button>
        )}

        <div className="flex items-center gap-1 ml-auto">
          <button onClick={() => zoom('in')} className="p-1.5 rounded-lg hover:bg-accent/50 transition-colors" title="Приблизить">
            <ZoomIn className="w-4 h-4" />
          </button>
          <button onClick={() => zoom('out')} className="p-1.5 rounded-lg hover:bg-accent/50 transition-colors" title="Отдалить">
            <ZoomOut className="w-4 h-4" />
          </button>
          <button onClick={resetView} className="p-1.5 rounded-lg hover:bg-accent/50 transition-colors" title="Сбросить вид">
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Tree Canvas */}
      <div
        ref={containerRef}
        className="flex-1 relative overflow-hidden bg-gradient-to-b from-slate-50 to-parchment-100 dark:from-slate-950 dark:to-slate-900 cursor-grab active:cursor-grabbing"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onWheel={handleWheel}
      >
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <div className="flex flex-col items-center gap-3">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
              <p className="text-muted-foreground">Загружаем семейное древо...</p>
            </div>
          </div>
        ) : (
          <svg
            ref={svgRef}
            className="w-full h-full"
            viewBox={`${viewBox.x} ${viewBox.y} ${viewBox.w} ${viewBox.h}`}
          >
            {/* Decorative tree trunk */}
            <path
              d="M600 780 C600 750 580 700 590 650 C600 600 620 580 600 540 C580 500 560 480 580 440"
              stroke="#5a3e28"
              strokeWidth="8"
              fill="none"
              strokeLinecap="round"
              opacity="0.3"
            />

            {/* Edges */}
            {edges.map((e, i) => {
              const isSpouse = e.type === 'SPOUSE'
              const midY = (e.y1 + e.y2) / 2
              return (
                <path
                  key={i}
                  d={isSpouse
                    ? `M${e.x1},${e.y1} L${e.x2},${e.y2}`
                    : `M${e.x1},${e.y1} C${e.x1},${midY} ${e.x2},${midY} ${e.x2},${e.y2}`}
                  stroke={isSpouse ? '#f59e0b' : '#5a3e28'}
                  strokeWidth={isSpouse ? 2 : 1.5}
                  fill="none"
                  strokeDasharray={isSpouse ? '6 3' : undefined}
                  opacity={0.6}
                  className="tree-branch"
                />
              )
            })}

            {/* Member nodes */}
            {filteredMembers.map(m => {
              const x = m.posX || 200
              const y = m.posY || 200
              const color = GENDER_COLORS[m.gender as keyof typeof GENDER_COLORS] || '#6b7280'
              const isSelected = selectedMember?.id === m.id
              const isDeceased = !m.isAlive

              return (
                <g
                  key={m.id}
                  className="tree-node-group cursor-pointer"
                  transform={`translate(${x},${y})`}
                  onClick={(e) => { e.stopPropagation(); setSelectedMember(m) }}
                >
                  {/* Glow ring for selected */}
                  {isSelected && (
                    <circle r={30} fill="none" stroke={color} strokeWidth={2} opacity={0.5} className="animate-glow-pulse" />
                  )}

                  {/* Main circle */}
                  <circle
                    r={22}
                    fill={isDeceased ? '#94a3b8' : color}
                    opacity={isDeceased ? 0.7 : 1}
                    stroke="white"
                    strokeWidth={2}
                    filter={`drop-shadow(0 0 ${isSelected ? 12 : 5}px ${color}80)`}
                    className="transition-all duration-300"
                  />

                  {/* Initials */}
                  <text
                    textAnchor="middle"
                    dy="0.35em"
                    fill="white"
                    fontSize="11"
                    fontWeight="600"
                    pointerEvents="none"
                  >
                    {m.firstName[0]}{m.lastName[0]}
                  </text>

                  {/* Memorial indicator */}
                  {m.isMemorial && (
                    <circle r={6} cx={18} cy={-18} fill="#7c3aed" stroke="white" strokeWidth={1.5} />
                  )}

                  {/* Name label */}
                  <text
                    y={32}
                    textAnchor="middle"
                    fill="currentColor"
                    fontSize="10"
                    fontWeight="500"
                    className="fill-foreground"
                    pointerEvents="none"
                  >
                    {m.firstName} {m.lastName}
                  </text>
                  {m.birthDate && (
                    <text
                      y={44}
                      textAnchor="middle"
                      fontSize="9"
                      className="fill-muted-foreground"
                      pointerEvents="none"
                    >
                      {formatYear(m.birthDate)}{m.deathDate ? ` — ${formatYear(m.deathDate)}` : ''}
                    </text>
                  )}
                </g>
              )
            })}

            {/* Empty state */}
            {filteredMembers.length === 0 && !loading && (
              <text x="600" y="400" textAnchor="middle" className="fill-muted-foreground" fontSize="16">
                Члены семьи не найдены
              </text>
            )}
          </svg>
        )}

        {/* Legend */}
        <div className="absolute bottom-4 left-4 card-premium p-3 text-xs space-y-1.5">
          <p className="font-medium text-sm mb-2">Обозначения</p>
          <div className="flex items-center gap-2">
            <div className="w-4 h-0.5 bg-amber-500 opacity-70" style={{ backgroundImage: 'repeating-linear-gradient(to right, #f59e0b 0, #f59e0b 6px, transparent 6px, transparent 9px)' }} />
            <span>Супруги</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-0.5 bg-amber-900" />
            <span>Родитель-ребёнок</span>
          </div>
          {Object.entries(GENDER_COLORS).map(([g, c]) => (
            <div key={g} className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full" style={{ background: c }} />
              <span>{g === 'MALE' ? 'Мужчина' : g === 'FEMALE' ? 'Женщина' : g === 'OTHER' ? 'Другое' : 'Неизвестно'}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Member detail panel */}
      <AnimatePresence>
        {selectedMember && (
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="absolute right-0 top-16 bottom-0 w-80 card-premium rounded-l-2xl rounded-r-none border-r-0 overflow-y-auto z-30 scrollbar-thin"
          >
            <div className="p-5">
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h2 className="font-display text-xl font-bold">
                    {selectedMember.firstName} {selectedMember.lastName}
                  </h2>
                  {selectedMember.maidenName && (
                    <p className="text-sm text-muted-foreground">в девичестве {selectedMember.maidenName}</p>
                  )}
                  {selectedMember.middleName && (
                    <p className="text-sm text-muted-foreground">{selectedMember.middleName}</p>
                  )}
                </div>
                <button
                  onClick={() => setSelectedMember(null)}
                  className="p-1.5 rounded-lg hover:bg-accent/50 transition-colors"
                  aria-label="Закрыть"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Avatar */}
              <div className="flex justify-center mb-4">
                <div
                  className="w-24 h-24 rounded-full flex items-center justify-center text-white text-2xl font-bold shadow-lg"
                  style={{ background: GENDER_COLORS[selectedMember.gender as keyof typeof GENDER_COLORS] }}
                >
                  {selectedMember.firstName[0]}{selectedMember.lastName[0]}
                </div>
              </div>

              {/* Status */}
              <div className="flex justify-center mb-4">
                <span className={cn(
                  'px-3 py-1 rounded-full text-xs font-medium',
                  selectedMember.isAlive
                    ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400'
                    : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                )}>
                  {selectedMember.isAlive ? '✦ Живёт' : '✦ Ушедший'}
                </span>
              </div>

              {/* Info rows */}
              <div className="space-y-3">
                {(selectedMember.birthDate || selectedMember.deathDate) && (
                  <div className="flex items-start gap-2.5">
                    <Calendar className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                    <div>
                      {selectedMember.birthDate && (
                        <p className="text-sm">Рождён: {formatDate(selectedMember.birthDate)}</p>
                      )}
                      {selectedMember.deathDate && (
                        <p className="text-sm">Ушёл: {formatDate(selectedMember.deathDate)}</p>
                      )}
                      {selectedMember.birthDate && (
                        <p className="text-xs text-muted-foreground">
                          {getAge(selectedMember.birthDate, selectedMember.deathDate)}
                        </p>
                      )}
                    </div>
                  </div>
                )}

                {selectedMember.birthPlace && (
                  <div className="flex items-start gap-2.5">
                    <MapPin className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                    <p className="text-sm">{selectedMember.birthPlace}</p>
                  </div>
                )}

                {selectedMember.profession && (
                  <div className="flex items-start gap-2.5">
                    <Briefcase className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                    <p className="text-sm">{selectedMember.profession}</p>
                  </div>
                )}
              </div>

              {/* Biography */}
              {selectedMember.biography && (
                <div className="mt-4">
                  <h3 className="font-medium text-sm mb-2">Биография</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{selectedMember.biography}</p>
                </div>
              )}

              {/* Awards */}
              {selectedMember.awards?.length > 0 && (
                <div className="mt-4">
                  <h3 className="font-medium text-sm mb-2 flex items-center gap-1.5">
                    <Star className="w-3.5 h-3.5 text-amber-500" />
                    Награды
                  </h3>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedMember.awards.map((award, i) => (
                      <span key={i} className="px-2 py-0.5 bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 rounded text-xs">
                        {award}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Relations */}
              {(selectedMember.relationsA?.length > 0 || selectedMember.relationsB?.length > 0) && (
                <div className="mt-4">
                  <h3 className="font-medium text-sm mb-2">Связи</h3>
                  <div className="space-y-1">
                    {selectedMember.relationsA?.map((r, i) => (
                      <div key={i} className="flex items-center gap-2 text-sm">
                        <span className="text-muted-foreground text-xs w-24">
                          {r.type === 'PARENT_CHILD' ? 'Ребёнок →' : r.type === 'SPOUSE' ? 'Супруг/а' : 'Брат/сестра'}
                        </span>
                        <button
                          onClick={() => setSelectedMember(r.memberB as unknown as FamilyMember)}
                          className="text-primary hover:underline"
                        >
                          {r.memberB.firstName} {r.memberB.lastName}
                        </button>
                      </div>
                    ))}
                    {selectedMember.relationsB?.map((r, i) => (
                      <div key={i} className="flex items-center gap-2 text-sm">
                        <span className="text-muted-foreground text-xs w-24">
                          {r.type === 'PARENT_CHILD' ? '← Родитель' : r.type === 'SPOUSE' ? 'Супруг/а' : 'Брат/сестра'}
                        </span>
                        <button
                          onClick={() => setSelectedMember(r.memberA as unknown as FamilyMember)}
                          className="text-primary hover:underline"
                        >
                          {r.memberA.firstName} {r.memberA.lastName}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Add member modal */}
      <AnimatePresence>
        {showAddModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
            onClick={e => { if (e.target === e.currentTarget) setShowAddModal(false) }}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="card-premium p-6 w-full max-w-md"
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-display text-xl font-bold">Добавить родственника</h2>
                <button onClick={() => setShowAddModal(false)} className="p-1.5 rounded-lg hover:bg-accent/50">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium mb-1">Имя *</label>
                    <input
                      value={newMember.firstName}
                      onChange={e => setNewMember(p => ({ ...p, firstName: e.target.value }))}
                      className="w-full px-3 py-2 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                      placeholder="Иван"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Фамилия *</label>
                    <input
                      value={newMember.lastName}
                      onChange={e => setNewMember(p => ({ ...p, lastName: e.target.value }))}
                      className="w-full px-3 py-2 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                      placeholder="Иванов"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Пол</label>
                  <select
                    value={newMember.gender}
                    onChange={e => setNewMember(p => ({ ...p, gender: e.target.value }))}
                    className="w-full px-3 py-2 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                  >
                    <option value="MALE">Мужской</option>
                    <option value="FEMALE">Женский</option>
                    <option value="OTHER">Другой</option>
                    <option value="UNKNOWN">Неизвестно</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Дата рождения</label>
                  <input
                    type="date"
                    value={newMember.birthDate}
                    onChange={e => setNewMember(p => ({ ...p, birthDate: e.target.value }))}
                    className="w-full px-3 py-2 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Профессия</label>
                  <input
                    value={newMember.profession}
                    onChange={e => setNewMember(p => ({ ...p, profession: e.target.value }))}
                    className="w-full px-3 py-2 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                    placeholder="Инженер, врач..."
                  />
                </div>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={newMember.isAlive}
                    onChange={e => setNewMember(p => ({ ...p, isAlive: e.target.checked }))}
                    className="rounded"
                  />
                  <span className="text-sm">Живёт сейчас</span>
                </label>

                <div className="flex gap-2 pt-2">
                  <button
                    onClick={() => setShowAddModal(false)}
                    className="flex-1 py-2 rounded-lg border border-border text-sm hover:bg-accent/50 transition-colors"
                  >
                    Отмена
                  </button>
                  <button
                    onClick={handleAddMember}
                    disabled={!newMember.firstName || !newMember.lastName}
                    className="flex-1 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 disabled:opacity-50 transition-colors"
                  >
                    Добавить
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
