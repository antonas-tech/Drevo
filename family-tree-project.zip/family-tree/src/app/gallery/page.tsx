'use client'

import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Image from 'next/image'
import { Header } from '@/components/header'
import { useAuth } from '@/components/providers'
import { formatDate, cn } from '@/lib/utils'
import {
  Heart, Flame, Smile, MessageCircle, Upload, X,
  ChevronLeft, ChevronRight, FolderOpen, Loader2, Plus
} from 'lucide-react'

interface Photo {
  id: string
  url: string
  caption?: string | null
  takenAt?: string | null
  location?: string | null
  familyMember?: { firstName: string; lastName: string } | null
  album?: { name: string } | null
  reactions: Array<{ type: string; userId: string }>
  _count: { reactions: number; comments: number }
}

interface Album {
  id: string
  name: string
  description?: string | null
  _count: { photos: number }
  photos: Array<{ url: string }>
}

const REACTIONS = [
  { type: 'heart', icon: Heart, color: 'text-red-500', label: 'Нравится' },
  { type: 'fire', icon: Flame, color: 'text-orange-500', label: 'Огонь' },
  { type: 'smile', icon: Smile, color: 'text-yellow-500', label: 'Улыбка' },
]

export default function GalleryPage() {
  const { user, token } = useAuth()
  const [photos, setPhotos] = useState<Photo[]>([])
  const [albums, setAlbums] = useState<Album[]>([])
  const [selectedAlbum, setSelectedAlbum] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [lightboxPhoto, setLightboxPhoto] = useState<Photo | null>(null)
  const [lightboxIndex, setLightboxIndex] = useState(0)
  const [uploading, setUploading] = useState(false)
  const [showUpload, setShowUpload] = useState(false)
  const [uploadCaption, setUploadCaption] = useState('')

  useEffect(() => {
    Promise.all([
      fetch(`/api/gallery${selectedAlbum ? `?albumId=${selectedAlbum}` : ''}`).then(r => r.json()),
      fetch('/api/gallery/albums').then(r => r.json()),
    ]).then(([photosData, albumsData]) => {
      if (photosData.success) setPhotos(photosData.data.photos)
      if (albumsData.success) setAlbums(albumsData.data)
    }).finally(() => setLoading(false))
  }, [selectedAlbum])

  const openLightbox = (photo: Photo) => {
    const idx = photos.findIndex(p => p.id === photo.id)
    setLightboxIndex(idx)
    setLightboxPhoto(photo)
  }

  const navigateLightbox = (dir: 'prev' | 'next') => {
    const newIdx = dir === 'next'
      ? Math.min(lightboxIndex + 1, photos.length - 1)
      : Math.max(lightboxIndex - 1, 0)
    setLightboxIndex(newIdx)
    setLightboxPhoto(photos[newIdx])
  }

  const handleReaction = async (photoId: string, type: string) => {
    if (!user) return
    // Optimistic update
    setPhotos(prev => prev.map(p => {
      if (p.id !== photoId) return p
      const hasReaction = p.reactions.some(r => r.type === type && r.userId === user.id)
      return {
        ...p,
        reactions: hasReaction
          ? p.reactions.filter(r => !(r.type === type && r.userId === user.id))
          : [...p.reactions, { type, userId: user.id }],
      }
    }))

    await fetch(`/api/gallery/${photoId}/react`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ type }),
    })
  }

  const handleUpload = async (file: File) => {
    if (!user) return
    setUploading(true)
    const formData = new FormData()
    formData.append('file', file)
    formData.append('caption', uploadCaption)
    if (selectedAlbum) formData.append('albumId', selectedAlbum)

    const res = await fetch('/api/gallery/upload', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
      body: formData,
    })
    const data = await res.json()
    if (data.success) {
      setPhotos(prev => [data.data, ...prev])
      setShowUpload(false)
      setUploadCaption('')
    }
    setUploading(false)
  }

  return (
    <div className="min-h-screen">
      <Header />
      <div className="container py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="section-header mb-1">Семейная галерея</h1>
            <p className="text-muted-foreground">Воспоминания, запечатлённые в фотографиях</p>
          </div>
          {user && (
            <button
              onClick={() => setShowUpload(true)}
              className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:bg-primary/90 transition-colors"
            >
              <Upload className="w-4 h-4" />
              Загрузить фото
            </button>
          )}
        </div>

        {/* Albums */}
        <div className="flex gap-3 mb-6 overflow-x-auto pb-2 scrollbar-thin">
          <button
            onClick={() => setSelectedAlbum(null)}
            className={cn(
              'flex items-center gap-2 px-4 py-2 rounded-xl border text-sm font-medium whitespace-nowrap transition-colors flex-shrink-0',
              !selectedAlbum ? 'bg-primary text-primary-foreground border-primary' : 'border-border hover:bg-accent/50'
            )}
          >
            <FolderOpen className="w-4 h-4" />
            Все фото
          </button>
          {albums.map(album => (
            <button
              key={album.id}
              onClick={() => setSelectedAlbum(album.id)}
              className={cn(
                'flex items-center gap-2 px-4 py-2 rounded-xl border text-sm font-medium whitespace-nowrap transition-colors flex-shrink-0',
                selectedAlbum === album.id ? 'bg-primary text-primary-foreground border-primary' : 'border-border hover:bg-accent/50'
              )}
            >
              {album.name}
              <span className="text-xs opacity-70">({album._count.photos})</span>
            </button>
          ))}
        </div>

        {/* Masonry Grid */}
        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : photos.length === 0 ? (
          <div className="text-center py-20 text-muted-foreground">
            <FolderOpen className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p>Нет фотографий</p>
            {user && (
              <button
                onClick={() => setShowUpload(true)}
                className="mt-4 flex items-center gap-2 mx-auto px-4 py-2 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:bg-primary/90 transition-colors"
              >
                <Plus className="w-4 h-4" />
                Добавить первое фото
              </button>
            )}
          </div>
        ) : (
          <div className="masonry-grid">
            {photos.map((photo, i) => (
              <motion.div
                key={photo.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: i * 0.05 }}
                className="masonry-item photo-card"
                onClick={() => openLightbox(photo)}
              >
                <div className="relative bg-muted rounded-xl overflow-hidden">
                  <img
                    src={photo.url}
                    alt={photo.caption || 'Семейное фото'}
                    className="w-full object-cover"
                    style={{ minHeight: '150px' }}
                    onError={e => {
                      (e.target as HTMLImageElement).src = `https://picsum.photos/seed/${photo.id}/400/300`
                    }}
                  />
                  <div className="photo-overlay p-3 flex flex-col justify-end">
                    {photo.caption && (
                      <p className="text-white text-sm font-medium">{photo.caption}</p>
                    )}
                    {photo.familyMember && (
                      <p className="text-white/70 text-xs">{photo.familyMember.firstName} {photo.familyMember.lastName}</p>
                    )}
                  </div>
                </div>

                {/* Reactions */}
                <div className="px-2 py-2 flex items-center gap-3" onClick={e => e.stopPropagation()}>
                  {REACTIONS.map(({ type, icon: Icon, color }) => {
                    const count = photo.reactions.filter(r => r.type === type).length
                    const active = user && photo.reactions.some(r => r.type === type && r.userId === user.id)
                    return (
                      <button
                        key={type}
                        onClick={() => handleReaction(photo.id, type)}
                        className={cn(
                          'flex items-center gap-1 text-xs transition-all',
                          active ? color : 'text-muted-foreground hover:text-foreground'
                        )}
                      >
                        <Icon className={cn('w-4 h-4', active && 'fill-current')} />
                        {count > 0 && count}
                      </button>
                    )
                  })}
                  <div className="flex items-center gap-1 text-xs text-muted-foreground ml-auto">
                    <MessageCircle className="w-3.5 h-3.5" />
                    {photo._count.comments}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* Lightbox */}
      <AnimatePresence>
        {lightboxPhoto && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/95 z-50 flex items-center justify-center"
            onClick={() => setLightboxPhoto(null)}
          >
            <button
              className="absolute top-4 right-4 p-2 rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors z-10"
              onClick={() => setLightboxPhoto(null)}
              aria-label="Закрыть"
            >
              <X className="w-5 h-5" />
            </button>

            {lightboxIndex > 0 && (
              <button
                className="absolute left-4 p-2 rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors z-10"
                onClick={e => { e.stopPropagation(); navigateLightbox('prev') }}
                aria-label="Предыдущее фото"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
            )}

            <motion.div
              key={lightboxPhoto.id}
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="max-w-4xl max-h-[80vh] mx-16"
              onClick={e => e.stopPropagation()}
            >
              <img
                src={lightboxPhoto.url}
                alt={lightboxPhoto.caption || ''}
                className="max-w-full max-h-[70vh] object-contain rounded-xl"
                onError={e => {
                  (e.target as HTMLImageElement).src = `https://picsum.photos/seed/${lightboxPhoto.id}/800/600`
                }}
              />
              {lightboxPhoto.caption && (
                <p className="text-white/80 text-center mt-3 text-sm">{lightboxPhoto.caption}</p>
              )}
            </motion.div>

            {lightboxIndex < photos.length - 1 && (
              <button
                className="absolute right-4 p-2 rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors z-10"
                onClick={e => { e.stopPropagation(); navigateLightbox('next') }}
                aria-label="Следующее фото"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Upload modal */}
      <AnimatePresence>
        {showUpload && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
            onClick={e => { if (e.target === e.currentTarget) setShowUpload(false) }}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="card-premium p-6 w-full max-w-md"
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-display text-xl font-bold">Загрузить фото</h2>
                <button onClick={() => setShowUpload(false)} className="p-1.5 rounded-lg hover:bg-accent/50">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div
                className="border-2 border-dashed border-border rounded-xl p-8 text-center cursor-pointer hover:border-primary/50 hover:bg-primary/5 transition-colors"
                onDrop={e => {
                  e.preventDefault()
                  const file = e.dataTransfer.files[0]
                  if (file) handleUpload(file)
                }}
                onDragOver={e => e.preventDefault()}
                onClick={() => {
                  const input = document.createElement('input')
                  input.type = 'file'
                  input.accept = 'image/*'
                  input.onchange = e => {
                    const file = (e.target as HTMLInputElement).files?.[0]
                    if (file) handleUpload(file)
                  }
                  input.click()
                }}
              >
                {uploading ? (
                  <Loader2 className="w-8 h-8 animate-spin mx-auto text-primary" />
                ) : (
                  <>
                    <Upload className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
                    <p className="text-sm text-muted-foreground">Перетащите фото или нажмите для выбора</p>
                    <p className="text-xs text-muted-foreground mt-1">JPEG, PNG, WebP до 10 МБ</p>
                  </>
                )}
              </div>

              <div className="mt-4">
                <label className="block text-sm font-medium mb-1.5">Подпись к фото</label>
                <input
                  value={uploadCaption}
                  onChange={e => setUploadCaption(e.target.value)}
                  placeholder="Расскажите историю этой фотографии..."
                  className="w-full px-3 py-2 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
