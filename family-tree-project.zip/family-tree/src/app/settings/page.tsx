'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Header } from '@/components/header'
import { useAuth } from '@/components/providers'
import { useTheme } from 'next-themes'
import { Settings, Moon, Sun, Bell, Lock, Eye, EyeOff, Loader2, CheckCircle2 } from 'lucide-react'

export default function SettingsPage() {
  const { user, token } = useAuth()
  const { theme, setTheme } = useTheme()
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [passwords, setPasswords] = useState({ current: '', newPwd: '', confirm: '' })
  const [showPwd, setShowPwd] = useState(false)
  const [notifications, setNotifications] = useState({
    friendRequests: true,
    newComments: true,
    newMessages: true,
    birthdays: true,
    familyUpdates: true,
  })

  const handleSaveProfile = async () => {
    setSaving(true)
    await new Promise(r => setTimeout(r, 800))
    setSaving(false)
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  const handleChangePassword = async () => {
    if (passwords.newPwd !== passwords.confirm) {
      alert('Пароли не совпадают')
      return
    }
    if (passwords.newPwd.length < 6) {
      alert('Минимум 6 символов')
      return
    }
    setSaving(true)
    const res = await fetch('/api/auth/change-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ currentPassword: passwords.current, newPassword: passwords.newPwd }),
    })
    const data = await res.json()
    setSaving(false)
    if (data.success) {
      setPasswords({ current: '', newPwd: '', confirm: '' })
      setSaved(true)
      setTimeout(() => setSaved(false), 2000)
    }
  }

  if (!user) return null

  return (
    <div className="min-h-screen">
      <Header />
      <div className="container py-10 max-w-2xl">
        <h1 className="section-header mb-8 flex items-center gap-3">
          <Settings className="w-7 h-7 text-primary" />
          Настройки
        </h1>

        <div className="space-y-6">
          {/* Appearance */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="card-premium p-6"
          >
            <h2 className="font-display text-lg font-semibold mb-4">Внешний вид</h2>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-sm">Тёмная тема</p>
                <p className="text-xs text-muted-foreground mt-0.5">Переключение между светлой и тёмной темой</p>
              </div>
              <button
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className={`relative w-12 h-6 rounded-full transition-colors ${
                  theme === 'dark' ? 'bg-primary' : 'bg-muted'
                }`}
                aria-label="Тёмная тема"
              >
                <span
                  className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-transform shadow ${
                    theme === 'dark' ? 'translate-x-7' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-3">
              {['light', 'dark'].map(t => (
                <button
                  key={t}
                  onClick={() => setTheme(t)}
                  className={`p-3 rounded-xl border-2 transition-all text-sm font-medium flex items-center gap-2 ${
                    theme === t ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/30'
                  }`}
                >
                  {t === 'light' ? <Sun className="w-4 h-4 text-amber-500" /> : <Moon className="w-4 h-4 text-blue-400" />}
                  {t === 'light' ? 'Светлая' : 'Тёмная'}
                </button>
              ))}
            </div>
          </motion.div>

          {/* Notifications */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="card-premium p-6"
          >
            <h2 className="font-display text-lg font-semibold mb-4 flex items-center gap-2">
              <Bell className="w-5 h-5" />
              Уведомления
            </h2>
            <div className="space-y-3">
              {Object.entries(notifications).map(([key, value]) => {
                const labels: Record<string, string> = {
                  friendRequests: 'Заявки в друзья',
                  newComments: 'Новые комментарии',
                  newMessages: 'Новые сообщения в чате',
                  birthdays: 'Дни рождения',
                  familyUpdates: 'Обновления семейного древа',
                }
                return (
                  <div key={key} className="flex items-center justify-between">
                    <p className="text-sm">{labels[key]}</p>
                    <button
                      onClick={() => setNotifications(n => ({ ...n, [key]: !value }))}
                      className={`relative w-10 h-5 rounded-full transition-colors ${
                        value ? 'bg-primary' : 'bg-muted'
                      }`}
                      aria-label={labels[key]}
                    >
                      <span
                        className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform shadow ${
                          value ? 'translate-x-5' : 'translate-x-0.5'
                        }`}
                      />
                    </button>
                  </div>
                )
              })}
            </div>
          </motion.div>

          {/* Security */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="card-premium p-6"
          >
            <h2 className="font-display text-lg font-semibold mb-4 flex items-center gap-2">
              <Lock className="w-5 h-5" />
              Безопасность
            </h2>
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium mb-1.5">Текущий пароль</label>
                <div className="relative">
                  <input
                    type={showPwd ? 'text' : 'password'}
                    value={passwords.current}
                    onChange={e => setPasswords(p => ({ ...p, current: e.target.value }))}
                    className="w-full px-3 py-2.5 pr-10 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPwd(!showPwd)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                  >
                    {showPwd ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5">Новый пароль</label>
                <input
                  type="password"
                  value={passwords.newPwd}
                  onChange={e => setPasswords(p => ({ ...p, newPwd: e.target.value }))}
                  className="w-full px-3 py-2.5 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5">Подтвердите новый пароль</label>
                <input
                  type="password"
                  value={passwords.confirm}
                  onChange={e => setPasswords(p => ({ ...p, confirm: e.target.value }))}
                  className="w-full px-3 py-2.5 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                />
              </div>
              <button
                onClick={handleChangePassword}
                disabled={saving || !passwords.current || !passwords.newPwd}
                className="w-full py-2.5 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 disabled:opacity-50 transition-colors flex items-center justify-center gap-2"
              >
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : saved ? <CheckCircle2 className="w-4 h-4" /> : null}
                {saved ? 'Сохранено!' : 'Сменить пароль'}
              </button>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  )
}
