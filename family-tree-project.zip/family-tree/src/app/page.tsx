'use client'

import { motion } from 'framer-motion'
import Link from 'next/link'
import { useAuth } from '@/components/providers'
import { Header } from '@/components/header'
import {
  TreePine, Image, MessageCircle, Sword, Calendar,
  BookOpen, Map, ArrowRight, Heart, Star, Users
} from 'lucide-react'

const features = [
  {
    icon: TreePine,
    title: 'Интерактивное древо',
    desc: 'Визуальное семейное дерево с анимациями, масштабированием и богатыми профилями каждого члена семьи',
    color: 'text-forest-600',
    bg: 'bg-forest-50 dark:bg-forest-900/20',
    href: '/tree',
  },
  {
    icon: Image,
    title: 'Семейная галерея',
    desc: 'Красивая лента с семейными фото, альбомами, лайками и историями за каждым снимком',
    color: 'text-mahogany-600',
    bg: 'bg-mahogany-50 dark:bg-mahogany-900/20',
    href: '/gallery',
  },
  {
    icon: MessageCircle,
    title: 'Семейный чат',
    desc: 'Реальное общение в реальном времени: личные диалоги, групповые комнаты, фото и эмодзи',
    color: 'text-primary',
    bg: 'bg-primary/5',
    href: '/chat',
  },
  {
    icon: Sword,
    title: 'Раздел «Армия»',
    desc: 'Память о военной службе предков: истории, звания, награды и путь на интерактивной карте',
    color: 'text-amber-600',
    bg: 'bg-amber-50 dark:bg-amber-900/20',
    href: '/army',
  },
  {
    icon: BookOpen,
    title: 'Летопись рода',
    desc: 'Хроника важнейших событий семьи — от истоков до наших дней',
    color: 'text-purple-600',
    bg: 'bg-purple-50 dark:bg-purple-900/20',
    href: '/chronicle',
  },
  {
    icon: Map,
    title: 'Карта семьи',
    desc: 'Интерактивная карта переселений и мест, связанных с историей рода',
    color: 'text-blue-600',
    bg: 'bg-blue-50 dark:bg-blue-900/20',
    href: '/map',
  },
]

const stats = [
  { label: 'Членов семьи', value: '7+', icon: Users },
  { label: 'Поколений', value: '4', icon: TreePine },
  { label: 'Ветеранов', value: '2', icon: Star },
  { label: 'Воспоминаний', value: '∞', icon: Heart },
]

export default function HomePage() {
  const { user } = useAuth()

  return (
    <div className="min-h-screen">
      <Header />

      {/* Hero */}
      <section className="relative overflow-hidden pt-20 pb-32">
        {/* Background */}
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-br from-parchment-100 via-background to-parchment-50 dark:from-slate-900 dark:via-background dark:to-slate-900" />
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-primary/5 rounded-full blur-3xl" />
        </div>

        <div className="container text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: 'easeOut' }}
          >
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-8">
              <TreePine className="w-4 h-4" />
              Цифровая семейная реликвия
            </div>

            {/* Title */}
            <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold tracking-tight mb-6">
              <span className="text-gradient">Семейное</span>
              <br />
              <span className="text-foreground">Древо</span>
            </h1>

            <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed">
              Место, где хранится память поколений. Ваши предки, история рода,
              семейные фото и живое общение — всё в одном красивом пространстве.
            </p>

            <div className="flex flex-wrap items-center justify-center gap-4">
              {user ? (
                <Link
                  href="/tree"
                  className="flex items-center gap-2 px-8 py-4 bg-primary text-primary-foreground rounded-xl font-semibold text-lg hover:bg-primary/90 transition-all hover:scale-105 shadow-lg shadow-primary/20"
                >
                  Открыть древо
                  <ArrowRight className="w-5 h-5" />
                </Link>
              ) : (
                <>
                  <Link
                    href="/register"
                    className="flex items-center gap-2 px-8 py-4 bg-primary text-primary-foreground rounded-xl font-semibold text-lg hover:bg-primary/90 transition-all hover:scale-105 shadow-lg shadow-primary/20"
                  >
                    Начать бесплатно
                    <ArrowRight className="w-5 h-5" />
                  </Link>
                  <Link
                    href="/login"
                    className="px-8 py-4 border border-border rounded-xl font-semibold text-lg hover:bg-accent/50 transition-colors"
                  >
                    Войти
                  </Link>
                </>
              )}
            </div>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="mt-20 grid grid-cols-2 sm:grid-cols-4 gap-6 max-w-2xl mx-auto"
          >
            {stats.map((stat) => {
              const Icon = stat.icon
              return (
                <div key={stat.label} className="text-center">
                  <div className="flex justify-center mb-2">
                    <Icon className="w-5 h-5 text-primary/60" />
                  </div>
                  <div className="font-display text-3xl font-bold text-foreground">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </div>
              )
            })}
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section className="container pb-24">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="section-header mb-4">Всё для вашей семьи</h2>
          <p className="text-muted-foreground text-lg max-w-xl mx-auto">
            Богатый функционал, продуманный дизайн и живое сообщество вашей семьи
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, i) => {
            const Icon = feature.icon
            return (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
              >
                <Link
                  href={feature.href}
                  className="group block card-premium p-6 hover:shadow-md transition-all duration-300 hover:border-primary/30"
                >
                  <div className={`inline-flex p-3 rounded-xl ${feature.bg} mb-4 group-hover:scale-110 transition-transform`}>
                    <Icon className={`w-6 h-6 ${feature.color}`} />
                  </div>
                  <h3 className="font-display text-xl font-semibold mb-2 group-hover:text-primary transition-colors">
                    {feature.title}
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {feature.desc}
                  </p>
                </Link>
              </motion.div>
            )
          })}
        </div>
      </section>

      {/* CTA */}
      <section className="container pb-24">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary/80 to-mahogany-700 p-12 text-center text-white"
        >
          <div className="absolute inset-0 opacity-10">
            <TreePine className="w-96 h-96 absolute -right-20 -bottom-20 text-white" />
          </div>
          <h2 className="font-display text-4xl font-bold mb-4 relative">
            Сохраните память на века
          </h2>
          <p className="text-white/80 text-lg mb-8 max-w-lg mx-auto relative">
            Присоединитесь к семье. Добавьте первого родственника и начните строить ваше семейное древо.
          </p>
          {!user && (
            <Link
              href="/register"
              className="inline-flex items-center gap-2 px-8 py-4 bg-white text-primary rounded-xl font-semibold hover:bg-white/90 transition-colors"
            >
              Начать сейчас
              <ArrowRight className="w-5 h-5" />
            </Link>
          )}
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8">
        <div className="container flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <TreePine className="w-4 h-4 text-primary" />
            <span className="font-display font-medium text-foreground">Семейное Древо</span>
          </div>
          <p>Создано с ❤️ для сохранения памяти поколений</p>
        </div>
      </footer>
    </div>
  )
}
