'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import { Header } from '@/components/header'
import { useAuth } from '@/components/providers'
import { formatDate, cn } from '@/lib/utils'
import {
  Shield, Users, TreePine, Image, MessageCircle, Settings,
  Activity, AlertTriangle, CheckCircle2, Ban, UserCheck,
  Loader2, Search, ChevronLeft, ChevronRight, MoreVertical
} from 'lucide-react'

interface User {
  id: string
  email: string
  username: string
  role: string
  isActive: boolean
  isBanned: boolean
  banReason?: string | null
  createdAt: string
  profile?: { avatar?: string | null } | null
}

const ROLE_COLORS: Record<string, string> = {
  ADMIN: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400',
  MODERATOR: 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400',
  USER: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
  GUEST: 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-400',
}

export default function AdminPage() {
  const { user, token } = useAuth()
  const router = useRouter()
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'tree' | 'gallery' | 'moderation'>('overview')
  const [users, setUsers] = useState<User[]>([])
  const [totalUsers, setTotalUsers] = useState(0)
  const [page, setPage] = useState(1)
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(false)
  const [stats, setStats] = useState({ users: 0, members: 0, photos: 0, messages: 0 })
  const [actionUser, setActionUser] = useState<User | null>(null)
  const [banReason, setBanReason] = useState('')

  useEffect(() => {
    if (!user) return
    if (!['ADMIN', 'MODERATOR'].includes(user.role)) {
      router.push('/')
    }
  }, [user])

  useEffect(() => {
    loadStats()
  }, [])

  useEffect(() => {
    if (activeTab === 'users') loadUsers()
  }, [activeTab, page, search])

  const loadStats = async () => {
    // Fetch basic stats
    const [usersRes, membersRes] = await Promise.all([
      fetch('/api/admin/users?limit=1', { headers: { Authorization: `Bearer ${token}` } }),
      fetch('/api/family/members'),
    ])
    const [ud, md] = await Promise.all([usersRes.json(), membersRes.json()])
    setStats({
      users: ud.data?.total || 0,
      members: md.data?.length || 0,
      photos: 0,
      messages: 0,
    })
  }

  const loadUsers = async () => {
    setLoading(true)
    const res = await fetch(`/api/admin/users?page=${page}&q=${search}`, {
      headers: { Authorization: `Bearer ${token}` }
    })
    const data = await res.json()
    if (data.success) {
      setUsers(data.data.users)
      setTotalUsers(data.data.total)
    }
    setLoading(false)
  }

  const userAction = async (userId: string, action: string, extra?: Record<string, unknown>) => {
    await fetch(`/api/admin/users/${userId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ action, ...extra }),
    })
    loadUsers()
    setActionUser(null)
    setBanReason('')
  }

  if (!user || !['ADMIN', 'MODERATOR'].includes(user.role)) {
    return null
  }

  const tabs = [
    { id: 'overview', label: 'Обзор', icon: Activity },
    { id: 'users', label: 'Пользователи', icon: Users },
    { id: 'tree', label: 'Древо', icon: TreePine },
    { id: 'gallery', label: 'Галерея', icon: Image },
    { id: 'moderation', label: 'Модерация', icon: Shield },
  ]

  const overviewStats = [
    { label: 'Пользователей', value: totalUsers || stats.users, icon: Users, color: 'text-blue-600', bg: 'bg-blue-50 dark:bg-blue-900/20' },
    { label: 'Членов семьи', value: stats.members, icon: TreePine, color: 'text-green-600', bg: 'bg-green-50 dark:bg-green-900/20' },
    { label: 'Фотографий', value: stats.photos, icon: Image, color: 'text-purple-600', bg: 'bg-purple-50 dark:bg-purple-900/20' },
    { label: 'Сообщений', value: stats.messages, icon: MessageCircle, color: 'text-amber-600', bg: 'bg-amber-50 dark:bg-amber-900/20' },
  ]

  return (
    <div className="min-h-screen">
      <Header />
      <div className="container py-8">
        <div className="flex items-center gap-3 mb-8">
          <div className="p-2 rounded-xl bg-primary/10">
            <Shield className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h1 className="section-header">Панель управления</h1>
            <p className="text-muted-foreground text-sm">Администрирование семейного сайта</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-6 border-b border-border overflow-x-auto pb-0 scrollbar-thin">
          {tabs.map(tab => {
            const Icon = tab.icon
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as typeof activeTab)}
                className={cn(
                  'flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors whitespace-nowrap',
                  activeTab === tab.id
                    ? 'border-primary text-primary'
                    : 'border-transparent text-muted-foreground hover:text-foreground'
                )}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            )
          })}
        </div>

        {/* Overview */}
        {activeTab === 'overview' && (
          <div>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              {overviewStats.map((stat, i) => {
                const Icon = stat.icon
                return (
                  <motion.div
                    key={stat.label}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.1 }}
                    className="card-premium p-5"
                  >
                    <div className={`inline-flex p-2 rounded-lg ${stat.bg} mb-3`}>
                      <Icon className={`w-5 h-5 ${stat.color}`} />
                    </div>
                    <p className="text-2xl font-bold">{stat.value}</p>
                    <p className="text-sm text-muted-foreground">{stat.label}</p>
                  </motion.div>
                )
              })}
            </div>

            <div className="card-premium p-6">
              <h2 className="font-semibold mb-4">Быстрые действия</h2>
              <div className="grid sm:grid-cols-2 gap-3">
                <button
                  onClick={() => setActiveTab('users')}
                  className="flex items-center gap-3 p-4 rounded-xl border border-border hover:bg-accent/50 transition-colors text-left"
                >
                  <Users className="w-5 h-5 text-blue-500" />
                  <div>
                    <p className="font-medium text-sm">Управление пользователями</p>
                    <p className="text-xs text-muted-foreground">Роли, блокировки, статусы</p>
                  </div>
                </button>
                <button
                  onClick={() => setActiveTab('moderation')}
                  className="flex items-center gap-3 p-4 rounded-xl border border-border hover:bg-accent/50 transition-colors text-left"
                >
                  <Shield className="w-5 h-5 text-red-500" />
                  <div>
                    <p className="font-medium text-sm">Модерация</p>
                    <p className="text-xs text-muted-foreground">Жалобы, блокировки</p>
                  </div>
                </button>
              </div>
            </div>

            {/* Warning */}
            <div className="mt-4 p-4 rounded-xl bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm">
                <p className="font-medium text-amber-800 dark:text-amber-400">Важно!</p>
                <p className="text-amber-700 dark:text-amber-500">
                  Смените пароль администратора (admin/admin) перед использованием на публичном сервере.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Users tab */}
        {activeTab === 'users' && (
          <div>
            {/* Search */}
            <div className="flex items-center gap-3 mb-4">
              <div className="relative flex-1 max-w-sm">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input
                  value={search}
                  onChange={e => { setSearch(e.target.value); setPage(1) }}
                  placeholder="Поиск по имени или email..."
                  className="w-full pl-9 pr-4 py-2 text-sm rounded-lg border border-input bg-background focus:outline-none focus:ring-2 focus:ring-ring"
                />
              </div>
              <span className="text-sm text-muted-foreground">Всего: {totalUsers}</span>
            </div>

            {/* Users table */}
            <div className="card-premium overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border bg-muted/50">
                      <th className="text-left px-4 py-3 font-medium text-muted-foreground">Пользователь</th>
                      <th className="text-left px-4 py-3 font-medium text-muted-foreground">Роль</th>
                      <th className="text-left px-4 py-3 font-medium text-muted-foreground">Статус</th>
                      <th className="text-left px-4 py-3 font-medium text-muted-foreground">Зарегистрирован</th>
                      <th className="text-left px-4 py-3 font-medium text-muted-foreground">Действия</th>
                    </tr>
                  </thead>
                  <tbody>
                    {loading ? (
                      <tr>
                        <td colSpan={5} className="text-center py-12">
                          <Loader2 className="w-5 h-5 animate-spin mx-auto text-muted-foreground" />
                        </td>
                      </tr>
                    ) : users.map(u => (
                      <tr key={u.id} className="border-b border-border hover:bg-accent/30 transition-colors">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-primary font-semibold text-xs flex-shrink-0">
                              {u.username[0]?.toUpperCase()}
                            </div>
                            <div>
                              <p className="font-medium">{u.username}</p>
                              <p className="text-xs text-muted-foreground">{u.email}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <span className={cn('px-2 py-0.5 rounded text-xs font-medium', ROLE_COLORS[u.role])}>
                            {u.role}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          {u.isBanned ? (
                            <span className="flex items-center gap-1 text-red-600 text-xs">
                              <Ban className="w-3.5 h-3.5" />
                              Заблокирован
                            </span>
                          ) : u.isActive ? (
                            <span className="flex items-center gap-1 text-green-600 text-xs">
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              Активен
                            </span>
                          ) : (
                            <span className="flex items-center gap-1 text-muted-foreground text-xs">
                              Неактивен
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-3 text-muted-foreground text-xs">
                          {formatDate(u.createdAt, { year: 'numeric', month: 'short', day: 'numeric' })}
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-1">
                            {!u.isBanned ? (
                              <button
                                onClick={() => setActionUser(u)}
                                className="px-2.5 py-1 text-xs rounded-lg border border-destructive/30 text-destructive hover:bg-destructive/10 transition-colors"
                              >
                                Заблокировать
                              </button>
                            ) : (
                              <button
                                onClick={() => userAction(u.id, 'unban')}
                                className="px-2.5 py-1 text-xs rounded-lg border border-green-500/30 text-green-600 hover:bg-green-50 dark:hover:bg-green-900/20 transition-colors"
                              >
                                Разблокировать
                              </button>
                            )}
                            {user.role === 'ADMIN' && u.id !== user.id && (
                              <select
                                value={u.role}
                                onChange={e => userAction(u.id, 'setRole', { role: e.target.value })}
                                className="px-2 py-1 text-xs rounded-lg border border-border bg-background"
                              >
                                <option value="USER">USER</option>
                                <option value="MODERATOR">MODERATOR</option>
                                <option value="ADMIN">ADMIN</option>
                              </select>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Pagination */}
              <div className="flex items-center justify-between px-4 py-3 border-t border-border">
                <span className="text-sm text-muted-foreground">
                  {(page - 1) * 20 + 1}–{Math.min(page * 20, totalUsers)} из {totalUsers}
                </span>
                <div className="flex gap-2">
                  <button
                    disabled={page === 1}
                    onClick={() => setPage(p => p - 1)}
                    className="p-1.5 rounded-lg hover:bg-accent/50 disabled:opacity-40 transition-colors"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    disabled={page * 20 >= totalUsers}
                    onClick={() => setPage(p => p + 1)}
                    className="p-1.5 rounded-lg hover:bg-accent/50 disabled:opacity-40 transition-colors"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tree management tab */}
        {activeTab === 'tree' && (
          <div className="card-premium p-6">
            <h2 className="font-semibold mb-4">Управление семейным древом</h2>
            <p className="text-muted-foreground text-sm mb-4">
              Перейдите в раздел «Древо» для визуального редактирования. Здесь — статистика.
            </p>
            <div className="grid sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl bg-muted/50 text-center">
                <p className="text-2xl font-bold text-primary">{stats.members}</p>
                <p className="text-sm text-muted-foreground mt-1">Членов семьи</p>
              </div>
            </div>
            <div className="mt-4">
              <a
                href="/tree"
                className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:bg-primary/90 transition-colors"
              >
                <TreePine className="w-4 h-4" />
                Открыть редактор древа
              </a>
            </div>
          </div>
        )}

        {/* Gallery tab */}
        {activeTab === 'gallery' && (
          <div className="card-premium p-6">
            <h2 className="font-semibold mb-4">Управление галереей</h2>
            <p className="text-muted-foreground text-sm mb-4">
              Модерация фотографий, альбомов и комментариев.
            </p>
            <a
              href="/gallery"
              className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:bg-primary/90 transition-colors"
            >
              <Image className="w-4 h-4" />
              Открыть галерею
            </a>
          </div>
        )}

        {/* Moderation tab */}
        {activeTab === 'moderation' && (
          <div className="card-premium p-6">
            <h2 className="font-semibold mb-4 flex items-center gap-2">
              <Shield className="w-5 h-5 text-primary" />
              Журнал модерации
            </h2>
            <p className="text-muted-foreground text-sm">
              Здесь будут отображаться все действия модераторов: блокировки, предупреждения, удаления.
            </p>
            <div className="mt-6 p-4 rounded-xl bg-muted/50 text-sm text-muted-foreground text-center">
              Журнал модерации пуст
            </div>
          </div>
        )}
      </div>

      {/* Ban modal */}
      {actionUser && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="card-premium p-6 w-full max-w-sm">
            <h2 className="font-semibold mb-1">Заблокировать пользователя</h2>
            <p className="text-sm text-muted-foreground mb-4">
              {actionUser.username} ({actionUser.email})
            </p>
            <label className="block text-sm font-medium mb-1.5">Причина блокировки</label>
            <textarea
              value={banReason}
              onChange={e => setBanReason(e.target.value)}
              placeholder="Укажите причину..."
              rows={3}
              className="w-full px-3 py-2 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring resize-none mb-4"
            />
            <div className="flex gap-2">
              <button
                onClick={() => { setActionUser(null); setBanReason('') }}
                className="flex-1 py-2 rounded-lg border border-border text-sm hover:bg-accent/50 transition-colors"
              >
                Отмена
              </button>
              <button
                onClick={() => userAction(actionUser.id, 'ban', { reason: banReason })}
                className="flex-1 py-2 rounded-lg bg-destructive text-destructive-foreground text-sm font-medium hover:bg-destructive/90 transition-colors"
              >
                Заблокировать
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
