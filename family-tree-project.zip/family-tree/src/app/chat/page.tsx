'use client'

import { useEffect, useRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Header } from '@/components/header'
import { useAuth } from '@/components/providers'
import { formatDate, cn } from '@/lib/utils'
import {
  Send, Search, Plus, Users, MessageCircle, X,
  Check, CheckCheck, Loader2, Smile, Image as ImageIcon
} from 'lucide-react'

interface Message {
  id: string
  content?: string | null
  fileUrl?: string | null
  type: string
  createdAt: string
  sender: { id: string; username: string; profile?: { avatar?: string | null } | null }
}

interface Chat {
  id: string
  name?: string | null
  isGroup: boolean
  updatedAt: string
  members: Array<{ user: { id: string; username: string; lastSeenAt?: string | null; profile?: { avatar?: string | null } | null } }>
  messages: Message[]
}

export default function ChatPage() {
  const { user, token } = useAuth()
  const [chats, setChats] = useState<Chat[]>([])
  const [selectedChat, setSelectedChat] = useState<Chat | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState('')
  const [loading, setLoading] = useState(true)
  const [sending, setSending] = useState(false)
  const [searchUsers, setSearchUsers] = useState('')
  const [users, setUsers] = useState<Array<{ id: string; username: string; profile?: { avatar?: string | null } | null }>>([])
  const [showNewChat, setShowNewChat] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const pollRef = useRef<NodeJS.Timeout | null>(null)

  useEffect(() => {
    if (!user) return
    loadChats()
  }, [user])

  useEffect(() => {
    if (selectedChat) {
      loadMessages(selectedChat.id)
      // Poll for new messages every 3 seconds
      pollRef.current = setInterval(() => loadMessages(selectedChat.id), 3000)
    }
    return () => { if (pollRef.current) clearInterval(pollRef.current) }
  }, [selectedChat?.id])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const loadChats = async () => {
    const res = await fetch('/api/chat', {
      headers: { Authorization: `Bearer ${token}` }
    })
    const data = await res.json()
    if (data.success) {
      setChats(data.data)
      if (data.data.length > 0 && !selectedChat) {
        setSelectedChat(data.data[0])
      }
    }
    setLoading(false)
  }

  const loadMessages = async (chatId: string) => {
    const res = await fetch(`/api/chat/${chatId}/messages`, {
      headers: { Authorization: `Bearer ${token}` }
    })
    const data = await res.json()
    if (data.success) setMessages(data.data.messages)
  }

  const sendMessage = async () => {
    if (!newMessage.trim() || !selectedChat || sending) return
    setSending(true)
    const content = newMessage.trim()
    setNewMessage('')

    // Optimistic
    const optimistic: Message = {
      id: `temp-${Date.now()}`,
      content,
      type: 'TEXT',
      createdAt: new Date().toISOString(),
      sender: { id: user!.id, username: user!.username }
    }
    setMessages(prev => [...prev, optimistic])

    const res = await fetch(`/api/chat/${selectedChat.id}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ content }),
    })
    const data = await res.json()
    if (data.success) {
      setMessages(prev => prev.map(m => m.id === optimistic.id ? data.data : m))
    }
    setSending(false)
  }

  const searchUsersAsync = async (q: string) => {
    if (!q) { setUsers([]); return }
    const res = await fetch(`/api/users?q=${encodeURIComponent(q)}`, {
      headers: { Authorization: `Bearer ${token}` }
    })
    const data = await res.json()
    if (data.success) setUsers(data.data)
  }

  const startDM = async (userId: string) => {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ memberIds: [userId] }),
    })
    const data = await res.json()
    if (data.success) {
      setChats(prev => [data.data, ...prev.filter(c => c.id !== data.data.id)])
      setSelectedChat(data.data)
      setShowNewChat(false)
      setSearchUsers('')
      setUsers([])
    }
  }

  const getChatName = (chat: Chat) => {
    if (chat.name) return chat.name
    const other = chat.members.find(m => m.user.id !== user?.id)
    return other?.user.username || 'Диалог'
  }

  const isOnline = (lastSeen?: string | null) => {
    if (!lastSeen) return false
    return new Date().getTime() - new Date(lastSeen).getTime() < 5 * 60 * 1000
  }

  if (!user) {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="container py-20 text-center text-muted-foreground">
          <MessageCircle className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p>Войдите, чтобы использовать чат</p>
        </div>
      </div>
    )
  }

  return (
    <div className="h-screen flex flex-col overflow-hidden">
      <Header />
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <div className="w-72 border-r border-border flex flex-col bg-card flex-shrink-0">
          <div className="p-3 border-b border-border">
            <div className="flex items-center gap-2 mb-3">
              <h2 className="font-display font-semibold flex-1">Сообщения</h2>
              <button
                onClick={() => setShowNewChat(!showNewChat)}
                className="p-1.5 rounded-lg hover:bg-accent/50 transition-colors text-primary"
                aria-label="Новый диалог"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            {/* Search users */}
            <AnimatePresence>
              {showNewChat && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="overflow-hidden"
                >
                  <input
                    value={searchUsers}
                    onChange={e => { setSearchUsers(e.target.value); searchUsersAsync(e.target.value) }}
                    placeholder="Найти пользователя..."
                    className="w-full px-3 py-2 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring mb-2"
                  />
                  {users.length > 0 && (
                    <div className="space-y-1 max-h-40 overflow-y-auto scrollbar-thin">
                      {users.map(u => (
                        <button
                          key={u.id}
                          onClick={() => startDM(u.id)}
                          className="w-full flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-accent/50 transition-colors text-left"
                        >
                          <div className="w-7 h-7 rounded-full bg-primary/20 flex items-center justify-center text-primary font-semibold text-xs flex-shrink-0">
                            {u.username[0].toUpperCase()}
                          </div>
                          <span className="text-sm">{u.username}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="flex-1 overflow-y-auto scrollbar-thin">
            {loading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
              </div>
            ) : chats.length === 0 ? (
              <div className="text-center py-8 px-4 text-muted-foreground text-sm">
                <Users className="w-8 h-8 mx-auto mb-2 opacity-30" />
                <p>Нет диалогов</p>
              </div>
            ) : (
              <div className="p-2 space-y-1">
                {chats.map(chat => {
                  const lastMessage = chat.messages[0]
                  const otherMember = chat.members.find(m => m.user.id !== user?.id)
                  const online = !chat.isGroup && isOnline(otherMember?.user.lastSeenAt)

                  return (
                    <button
                      key={chat.id}
                      onClick={() => setSelectedChat(chat)}
                      className={cn(
                        'w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-colors text-left',
                        selectedChat?.id === chat.id ? 'bg-primary/10 text-primary' : 'hover:bg-accent/50'
                      )}
                    >
                      <div className="relative flex-shrink-0">
                        <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center font-semibold text-sm text-primary">
                          {chat.isGroup ? <Users className="w-5 h-5" /> : getChatName(chat)[0]?.toUpperCase()}
                        </div>
                        {online && (
                          <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-card" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">{getChatName(chat)}</p>
                        {lastMessage && (
                          <p className="text-xs text-muted-foreground truncate">
                            {lastMessage.sender.username}: {lastMessage.content}
                          </p>
                        )}
                      </div>
                    </button>
                  )
                })}
              </div>
            )}
          </div>
        </div>

        {/* Chat area */}
        {selectedChat ? (
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Chat header */}
            <div className="px-4 py-3 border-b border-border bg-card flex items-center gap-3 flex-shrink-0">
              <div className="w-9 h-9 rounded-full bg-primary/20 flex items-center justify-center font-semibold text-sm text-primary">
                {selectedChat.isGroup ? <Users className="w-4 h-4" /> : getChatName(selectedChat)[0]?.toUpperCase()}
              </div>
              <div>
                <p className="font-semibold text-sm">{getChatName(selectedChat)}</p>
                <p className="text-xs text-muted-foreground">
                  {selectedChat.isGroup
                    ? `${selectedChat.members.length} участников`
                    : 'Личный диалог'}
                </p>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin">
              {messages.map((msg) => {
                const isMe = msg.sender.id === user.id
                return (
                  <div key={msg.id} className={cn('flex', isMe ? 'justify-end' : 'justify-start')}>
                    {!isMe && (
                      <div className="w-7 h-7 rounded-full bg-secondary flex items-center justify-center text-xs font-semibold mr-2 flex-shrink-0 self-end">
                        {msg.sender.username[0]?.toUpperCase()}
                      </div>
                    )}
                    <div className="max-w-xs lg:max-w-md">
                      {!isMe && (
                        <p className="text-xs text-muted-foreground mb-1 ml-1">{msg.sender.username}</p>
                      )}
                      <div className={isMe ? 'chat-bubble-me' : 'chat-bubble-other'}>
                        {msg.content && <p className="text-sm leading-relaxed">{msg.content}</p>}
                        {msg.fileUrl && (
                          <img src={msg.fileUrl} alt="фото" className="rounded-lg max-w-full" />
                        )}
                      </div>
                      <p className="text-[10px] text-muted-foreground mt-0.5 px-1 flex items-center gap-1" style={{ justifyContent: isMe ? 'flex-end' : 'flex-start' }}>
                        {new Date(msg.createdAt).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}
                        {isMe && <CheckCheck className="w-3 h-3" />}
                      </p>
                    </div>
                  </div>
                )
              })}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-3 border-t border-border bg-card flex items-end gap-2 flex-shrink-0">
              <button className="p-2 rounded-lg hover:bg-accent/50 transition-colors text-muted-foreground" aria-label="Эмодзи">
                <Smile className="w-5 h-5" />
              </button>
              <textarea
                value={newMessage}
                onChange={e => setNewMessage(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault()
                    sendMessage()
                  }
                }}
                placeholder="Написать сообщение..."
                rows={1}
                className="flex-1 px-3 py-2.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring resize-none max-h-32 scrollbar-thin"
                style={{ height: 'auto' }}
              />
              <button
                onClick={sendMessage}
                disabled={!newMessage.trim() || sending}
                className="p-2.5 rounded-xl bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50 transition-colors flex-shrink-0"
                aria-label="Отправить"
              >
                {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              </button>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex items-center justify-center text-muted-foreground">
            <div className="text-center">
              <MessageCircle className="w-12 h-12 mx-auto mb-3 opacity-20" />
              <p>Выберите диалог</p>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
