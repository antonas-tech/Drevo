'use client'

import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Header } from '@/components/header'
import { formatDate, cn } from '@/lib/utils'
import { Calendar, MapPin, Heart, Star, Clock, Loader2 } from 'lucide-react'

interface FamilyEvent {
  id: string
  title: string
  description?: string | null
  date: string
  location?: string | null
  type: string
  coverPhoto?: string | null
}

const TYPE_CONFIG: Record<string, { label: string; icon: typeof Calendar; color: string }> = {
  event: { label: 'Событие', icon: Calendar, color: 'text-blue-600' },
  birthday: { label: 'День рождения', icon: Heart, color: 'text-pink-600' },
  anniversary: { label: 'Годовщина', icon: Star, color: 'text-amber-600' },
  memorial: { label: 'Памятная дата', icon: Clock, color: 'text-slate-600' },
}

export default function EventsPage() {
  const [events, setEvents] = useState<FamilyEvent[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/events')
      .then(r => r.json())
      .then(d => { if (d.success) setEvents(d.data) })
      .finally(() => setLoading(false))
  }, [])

  const upcoming = events.filter(e => new Date(e.date) >= new Date())
  const past = events.filter(e => new Date(e.date) < new Date())

  return (
    <div className="min-h-screen">
      <Header />
      <div className="container py-10">
        <div className="mb-10">
          <h1 className="section-header mb-2 flex items-center gap-3">
            <Calendar className="w-7 h-7 text-primary" />
            Семейные события
          </h1>
          <p className="text-muted-foreground">Праздники, встречи и памятные даты нашей семьи</p>
        </div>

        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : (
          <>
            {upcoming.length > 0 && (
              <div className="mb-10">
                <h2 className="text-lg font-semibold mb-4 text-primary">Предстоящие</h2>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {upcoming.map((event, i) => (
                    <EventCard key={event.id} event={event} index={i} />
                  ))}
                </div>
              </div>
            )}

            {past.length > 0 && (
              <div>
                <h2 className="text-lg font-semibold mb-4 text-muted-foreground">История</h2>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 opacity-70">
                  {past.map((event, i) => (
                    <EventCard key={event.id} event={event} index={i} />
                  ))}
                </div>
              </div>
            )}

            {events.length === 0 && (
              <div className="text-center py-20 text-muted-foreground">
                <Calendar className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p>Нет событий</p>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}

function EventCard({ event, index }: { event: FamilyEvent; index: number }) {
  const config = TYPE_CONFIG[event.type] || TYPE_CONFIG.event
  const Icon = config.icon

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.1 }}
      className="card-premium p-5 hover:shadow-md transition-shadow"
    >
      <div className="flex items-start gap-3 mb-3">
        <div className={cn('p-2 rounded-lg bg-muted', config.color)}>
          <Icon className="w-5 h-5" />
        </div>
        <div>
          <span className="text-xs text-muted-foreground">{config.label}</span>
          <h3 className="font-semibold">{event.title}</h3>
        </div>
      </div>

      {event.description && (
        <p className="text-sm text-muted-foreground mb-3 leading-relaxed">{event.description}</p>
      )}

      <div className="flex flex-col gap-1 text-xs text-muted-foreground">
        <span className="flex items-center gap-1.5">
          <Calendar className="w-3.5 h-3.5" />
          {formatDate(event.date)}
        </span>
        {event.location && (
          <span className="flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5" />
            {event.location}
          </span>
        )}
      </div>
    </motion.div>
  )
}
