import { NextRequest } from 'next/server'
import bcrypt from 'bcryptjs'
import { prisma } from '@/lib/prisma'
import { getAuthUser } from '@/lib/auth'
import { ok, err, unauthorized, serverError } from '@/lib/api'

export async function POST(request: NextRequest) {
  const user = await getAuthUser(request)
  if (!user) return unauthorized()

  try {
    const { currentPassword, newPassword } = await request.json()

    if (!currentPassword || !newPassword) return err('Все поля обязательны')
    if (newPassword.length < 6) return err('Минимум 6 символов')

    const match = await bcrypt.compare(currentPassword, user.passwordHash)
    if (!match) return err('Неверный текущий пароль')

    const newHash = await bcrypt.hash(newPassword, 12)
    await prisma.user.update({
      where: { id: user.id },
      data: { passwordHash: newHash }
    })

    return ok({ changed: true })
  } catch (e) {
    return serverError(e)
  }
}
