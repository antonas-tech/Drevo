import { NextRequest } from 'next/server'
import bcrypt from 'bcryptjs'
import { prisma } from '@/lib/prisma'
import { signToken } from '@/lib/auth'
import { ok, err, serverError } from '@/lib/api'
import { z } from 'zod'

const loginSchema = z.object({
  login: z.string().min(1, 'Введите логин или email'),
  password: z.string().min(1, 'Введите пароль'),
})

// Simple rate limiting in memory (use Redis in production)
const attempts = new Map<string, { count: number; reset: number }>()

function checkRateLimit(ip: string): boolean {
  const now = Date.now()
  const entry = attempts.get(ip)
  if (entry && now < entry.reset) {
    if (entry.count >= 5) return false
    entry.count++
  } else {
    attempts.set(ip, { count: 1, reset: now + 60_000 })
  }
  return true
}

export async function POST(request: NextRequest) {
  try {
    const ip = request.headers.get('x-forwarded-for') || 'unknown'
    if (!checkRateLimit(ip)) {
      return err('Слишком много попыток. Попробуйте через минуту.', 429)
    }

    const body = await request.json()
    const parsed = loginSchema.safeParse(body)
    if (!parsed.success) {
      return err(parsed.error.errors[0].message)
    }

    const { login, password } = parsed.data

    // Find user by email or username
    const user = await prisma.user.findFirst({
      where: {
        OR: [
          { email: login.toLowerCase() },
          { username: login.toLowerCase() },
        ],
      },
      include: { profile: true },
    })

    if (!user) {
      return err('Неверный логин или пароль', 401)
    }

    if (user.isBanned) {
      return err(`Аккаунт заблокирован. Причина: ${user.banReason || 'нарушение правил'}`, 403)
    }

    if (!user.isActive) {
      return err('Аккаунт деактивирован', 403)
    }

    const passwordMatch = await bcrypt.compare(password, user.passwordHash)
    if (!passwordMatch) {
      return err('Неверный логин или пароль', 401)
    }

    // Update last seen
    await prisma.user.update({
      where: { id: user.id },
      data: { lastSeenAt: new Date() },
    })

    const token = signToken({ userId: user.id, email: user.email, role: user.role })

    return ok({
      token,
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        role: user.role,
        profile: user.profile,
      },
    })
  } catch (e) {
    return serverError(e)
  }
}
