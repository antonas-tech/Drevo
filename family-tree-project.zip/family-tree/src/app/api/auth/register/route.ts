import { NextRequest } from 'next/server'
import bcrypt from 'bcryptjs'
import { prisma } from '@/lib/prisma'
import { signToken } from '@/lib/auth'
import { ok, err, serverError } from '@/lib/api'
import { z } from 'zod'

const registerSchema = z.object({
  username: z.string()
    .min(3, 'Минимум 3 символа')
    .max(30, 'Максимум 30 символов')
    .regex(/^[a-z0-9_]+$/, 'Только латинские буквы, цифры и _'),
  email: z.string().email('Некорректный email'),
  password: z.string().min(6, 'Минимум 6 символов').max(100),
})

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const parsed = registerSchema.safeParse(body)
    if (!parsed.success) {
      return err(parsed.error.errors[0].message)
    }

    const { username, email, password } = parsed.data

    // Check duplicates
    const existing = await prisma.user.findFirst({
      where: {
        OR: [
          { email: email.toLowerCase() },
          { username: username.toLowerCase() },
        ],
      },
    })

    if (existing) {
      if (existing.email === email.toLowerCase()) {
        return err('Email уже используется')
      }
      return err('Имя пользователя уже занято')
    }

    const passwordHash = await bcrypt.hash(password, 12)

    const user = await prisma.user.create({
      data: {
        email: email.toLowerCase(),
        username: username.toLowerCase(),
        passwordHash,
        profile: {
          create: {},
        },
      },
      include: { profile: true },
    })

    const token = signToken({ userId: user.id, email: user.email, role: user.role })

    return ok({
      token,
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        role: user.role,
        profile: user.profile,
      },
    }, 201)
  } catch (e) {
    return serverError(e)
  }
}
