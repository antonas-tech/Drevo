import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getAuthUser } from '@/lib/auth'
import { ok, unauthorized, serverError } from '@/lib/api'

export async function GET(request: NextRequest) {
  const user = await getAuthUser(request)
  if (!user) return unauthorized()

  try {
    const { searchParams } = new URL(request.url)
    const q = searchParams.get('q') || ''
    const limit = parseInt(searchParams.get('limit') || '20')

    const users = await prisma.user.findMany({
      where: {
        id: { not: user.id },
        isActive: true,
        isBanned: false,
        OR: q ? [
          { username: { contains: q, mode: 'insensitive' } },
          { email: { contains: q, mode: 'insensitive' } },
        ] : undefined,
      },
      select: {
        id: true,
        username: true,
        lastSeenAt: true,
        role: true,
        profile: {
          select: { avatar: true, bio: true, location: true }
        }
      },
      take: limit,
      orderBy: { username: 'asc' }
    })

    return ok(users)
  } catch (e) {
    return serverError(e)
  }
}
