import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getAuthUser } from '@/lib/auth'
import { ok, unauthorized, serverError } from '@/lib/api'

export async function GET() {
  try {
    const events = await prisma.familyEvent.findMany({
      where: { isPublic: true },
      orderBy: { date: 'asc' }
    })
    return ok(events)
  } catch (e) {
    return serverError(e)
  }
}

export async function POST(request: NextRequest) {
  const user = await getAuthUser(request)
  if (!user) return unauthorized()

  try {
    const body = await request.json()
    const event = await prisma.familyEvent.create({
      data: { ...body, date: new Date(body.date) }
    })
    return ok(event, 201)
  } catch (e) {
    return serverError(e)
  }
}
