import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getAuthUser } from '@/lib/auth'
import { ok, err, unauthorized, forbidden, serverError } from '@/lib/api'

export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
  const user = await getAuthUser(request)
  if (!user) return unauthorized()
  if (!['ADMIN', 'MODERATOR'].includes(user.role)) return forbidden()

  try {
    const { action, reason, role } = await request.json()

    if (params.id === user.id) return err('Нельзя изменить собственный аккаунт')

    const target = await prisma.user.findUnique({ where: { id: params.id } })
    if (!target) return err('Пользователь не найден', 404)

    // Only admin can change roles or ban other admins
    if (target.role === 'ADMIN' && user.role !== 'ADMIN') return forbidden()

    let updateData: Record<string, unknown> = {}

    if (action === 'ban') {
      updateData = { isBanned: true, banReason: reason }
    } else if (action === 'unban') {
      updateData = { isBanned: false, banReason: null }
    } else if (action === 'setRole' && user.role === 'ADMIN') {
      updateData = { role }
    } else if (action === 'deactivate') {
      updateData = { isActive: false }
    } else if (action === 'activate') {
      updateData = { isActive: true }
    } else {
      return err('Неизвестное действие')
    }

    const updated = await prisma.user.update({
      where: { id: params.id },
      data: updateData,
    })

    // Log moderation action
    if (['ban', 'unban'].includes(action)) {
      await prisma.moderationLog.create({
        data: {
          moderatorId: user.id,
          targetId: params.id,
          action: action === 'ban' ? 'BAN' : 'UNBAN',
          reason,
        }
      })
    }

    return ok(updated)
  } catch (e) {
    return serverError(e)
  }
}
