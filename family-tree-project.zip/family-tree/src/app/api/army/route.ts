import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getAuthUser } from '@/lib/auth'
import { ok, err, unauthorized, serverError } from '@/lib/api'

export async function GET() {
  try {
    const records = await prisma.armyRecord.findMany({
      include: {
        familyMember: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            middleName: true,
            birthDate: true,
            deathDate: true,
            photo: true,
            isAlive: true,
          }
        }
      },
      orderBy: [
        { isVeteran: 'desc' },
        { startYear: 'asc' }
      ]
    })

    return ok(records)
  } catch (e) {
    return serverError(e)
  }
}

export async function POST(request: NextRequest) {
  const user = await getAuthUser(request)
  if (!user) return unauthorized()

  try {
    const body = await request.json()
    const { familyMemberId, ...data } = body

    if (!familyMemberId) return err('familyMemberId обязателен')

    const record = await prisma.armyRecord.upsert({
      where: { familyMemberId },
      update: data,
      create: { familyMemberId, ...data }
    })

    return ok(record)
  } catch (e) {
    return serverError(e)
  }
}
