import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getAuthUser } from '@/lib/auth'
import { ok, err, unauthorized, serverError } from '@/lib/api'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const albumId = searchParams.get('albumId')
    const memberId = searchParams.get('memberId')
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')
    const skip = (page - 1) * limit

    const where: Record<string, unknown> = { isApproved: true }
    if (albumId) where.albumId = albumId
    if (memberId) where.familyMemberId = memberId

    const [photos, total] = await Promise.all([
      prisma.photo.findMany({
        where,
        include: {
          uploadedBy: { select: { username: true } },
          album: true,
          familyMember: { select: { firstName: true, lastName: true } },
          reactions: true,
          comments: {
            where: { isDeleted: false },
            include: { author: { select: { username: true, profile: true } } },
            take: 5,
          },
          _count: { select: { reactions: true, comments: true } }
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      prisma.photo.count({ where })
    ])

    return ok({ photos, total, page, pages: Math.ceil(total / limit) })
  } catch (e) {
    return serverError(e)
  }
}
