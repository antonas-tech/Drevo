import { NextRequest } from 'next/server'
import { writeFile, mkdir } from 'fs/promises'
import { join } from 'path'
import { randomUUID } from 'crypto'
import { prisma } from '@/lib/prisma'
import { getAuthUser } from '@/lib/auth'
import { ok, err, unauthorized, serverError } from '@/lib/api'

const ALLOWED_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/gif']
const MAX_SIZE = 10 * 1024 * 1024 // 10MB

export async function POST(request: NextRequest) {
  const user = await getAuthUser(request)
  if (!user) return unauthorized()

  try {
    const formData = await request.formData()
    const file = formData.get('file') as File | null
    const caption = formData.get('caption') as string | null
    const albumId = formData.get('albumId') as string | null
    const familyMemberId = formData.get('familyMemberId') as string | null
    const location = formData.get('location') as string | null

    if (!file) return err('Файл не выбран')
    if (!ALLOWED_TYPES.includes(file.type)) return err('Допустимы только изображения (JPEG, PNG, WebP, GIF)')
    if (file.size > MAX_SIZE) return err('Файл слишком большой (максимум 10MB)')

    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)

    // Save file
    const uploadDir = join(process.cwd(), 'public', 'uploads')
    await mkdir(uploadDir, { recursive: true })

    const ext = file.name.split('.').pop()
    const filename = `${randomUUID()}.${ext}`
    const filepath = join(uploadDir, filename)
    await writeFile(filepath, buffer)

    const url = `/uploads/${filename}`

    const photo = await prisma.photo.create({
      data: {
        url,
        caption,
        location,
        albumId: albumId || null,
        familyMemberId: familyMemberId || null,
        uploadedById: user.id,
      }
    })

    return ok(photo, 201)
  } catch (e) {
    return serverError(e)
  }
}
