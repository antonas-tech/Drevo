import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getAuthUser } from '@/lib/auth'
import { ok, unauthorized, serverError } from '@/lib/api'

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  const user = await getAuthUser(request)
  if (!user) return unauthorized()

  try {
    const { type } = await request.json()
    const photoId = params.id

    const existing = await prisma.reaction.findUnique({
      where: { userId_photoId_type: { userId: user.id, photoId, type } }
    })

    if (existing) {
      await prisma.reaction.delete({ where: { id: existing.id } })
      return ok({ removed: true })
    } else {
      const reaction = await prisma.reaction.create({
        data: { userId: user.id, photoId, type }
      })
      return ok(reaction)
    }
  } catch (e) {
    return serverError(e)
  }
}
