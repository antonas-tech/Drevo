import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getAuthUser } from '@/lib/auth'
import { ok, unauthorized, serverError } from '@/lib/api'

export async function GET() {
  try {
    const albums = await prisma.album.findMany({
      include: {
        _count: { select: { photos: true } },
        photos: { take: 1, orderBy: { createdAt: 'desc' }, select: { url: true } }
      },
      orderBy: { createdAt: 'desc' }
    })
    return ok(albums)
  } catch (e) {
    return serverError(e)
  }
}

export async function POST(request: NextRequest) {
  const user = await getAuthUser(request)
  if (!user) return unauthorized()

  try {
    const { name, description } = await request.json()
    const album = await prisma.album.create({
      data: { name, description }
    })
    return ok(album, 201)
  } catch (e) {
    return serverError(e)
  }
}
