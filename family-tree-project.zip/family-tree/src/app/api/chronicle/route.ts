import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getAuthUser } from '@/lib/auth'
import { ok, unauthorized, serverError } from '@/lib/api'

export async function GET() {
  try {
    const entries = await prisma.chronicle.findMany({
      where: { isPublic: true },
      orderBy: [{ year: 'asc' }, { date: 'asc' }]
    })
    return ok(entries)
  } catch (e) {
    return serverError(e)
  }
}

export async function POST(request: NextRequest) {
  const user = await getAuthUser(request)
  if (!user) return unauthorized()

  try {
    const body = await request.json()
    const entry = await prisma.chronicle.create({ data: body })
    return ok(entry, 201)
  } catch (e) {
    return serverError(e)
  }
}
