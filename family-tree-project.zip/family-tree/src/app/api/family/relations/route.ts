import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getAuthUser } from '@/lib/auth'
import { ok, err, unauthorized, serverError } from '@/lib/api'
import { z } from 'zod'

const relationSchema = z.object({
  memberAId: z.string(),
  memberBId: z.string(),
  type: z.enum(['PARENT_CHILD', 'SPOUSE', 'SIBLING']),
})

export async function POST(request: NextRequest) {
  const user = await getAuthUser(request)
  if (!user) return unauthorized()

  try {
    const body = await request.json()
    const parsed = relationSchema.safeParse(body)
    if (!parsed.success) return err(parsed.error.errors[0].message)

    const { memberAId, memberBId, type } = parsed.data

    if (memberAId === memberBId) {
      return err('Нельзя создать связь с самим собой')
    }

    // Validate logical consistency
    if (type === 'PARENT_CHILD') {
      const parent = await prisma.familyMember.findUnique({ where: { id: memberAId } })
      const child = await prisma.familyMember.findUnique({ where: { id: memberBId } })
      if (parent?.birthDate && child?.birthDate) {
        if (new Date(parent.birthDate) >= new Date(child.birthDate)) {
          // Allow but warn — not blocking
        }
      }
    }

    const relation = await prisma.familyRelation.create({
      data: { memberAId, memberBId, type }
    })

    return ok(relation, 201)
  } catch (e: unknown) {
    if ((e as { code?: string })?.code === 'P2002') {
      return err('Такая связь уже существует')
    }
    return serverError(e)
  }
}

export async function DELETE(request: NextRequest) {
  const user = await getAuthUser(request)
  if (!user) return unauthorized()

  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')
    if (!id) return err('ID связи обязателен')

    await prisma.familyRelation.delete({ where: { id } })
    return ok({ deleted: true })
  } catch (e) {
    return serverError(e)
  }
}
