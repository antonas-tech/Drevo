import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getAuthUser } from '@/lib/auth'
import { ok, err, unauthorized, forbidden, notFound, serverError } from '@/lib/api'
import { z } from 'zod'

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const member = await prisma.familyMember.findUnique({
      where: { id: params.id },
      include: {
        relationsA: { include: { memberB: true } },
        relationsB: { include: { memberA: true } },
        armyRecord: true,
        photos: { take: 20, orderBy: { createdAt: 'desc' } },
        linkedUser: { include: { profile: true } },
      }
    })

    if (!member) return notFound('Член семьи')
    return ok(member)
  } catch (e) {
    return serverError(e)
  }
}

const updateSchema = z.object({
  firstName: z.string().min(1).max(50).optional(),
  lastName: z.string().min(1).max(50).optional(),
  maidenName: z.string().max(50).optional().nullable(),
  middleName: z.string().max(50).optional().nullable(),
  gender: z.enum(['MALE', 'FEMALE', 'OTHER', 'UNKNOWN']).optional(),
  birthDate: z.string().optional().nullable(),
  deathDate: z.string().optional().nullable(),
  birthPlace: z.string().max(200).optional().nullable(),
  biography: z.string().max(5000).optional().nullable(),
  profession: z.string().max(200).optional().nullable(),
  isAlive: z.boolean().optional(),
  isMemorial: z.boolean().optional(),
  memorialText: z.string().max(2000).optional().nullable(),
  generation: z.number().int().optional(),
  posX: z.number().optional(),
  posY: z.number().optional(),
  awards: z.array(z.string()).optional(),
  cities: z.array(z.string()).optional(),
})

export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
  const user = await getAuthUser(request)
  if (!user) return unauthorized()

  try {
    const body = await request.json()
    const parsed = updateSchema.safeParse(body)
    if (!parsed.success) return err(parsed.error.errors[0].message)

    const existing = await prisma.familyMember.findUnique({ where: { id: params.id } })
    if (!existing) return notFound('Член семьи')

    const data = parsed.data
    const member = await prisma.familyMember.update({
      where: { id: params.id },
      data: {
        ...data,
        birthDate: data.birthDate ? new Date(data.birthDate) : data.birthDate,
        deathDate: data.deathDate ? new Date(data.deathDate) : data.deathDate,
      }
    })

    return ok(member)
  } catch (e) {
    return serverError(e)
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  const user = await getAuthUser(request)
  if (!user) return unauthorized()
  if (!['ADMIN', 'MODERATOR'].includes(user.role)) return forbidden()

  try {
    await prisma.familyMember.delete({ where: { id: params.id } })
    return ok({ deleted: true })
  } catch (e) {
    return serverError(e)
  }
}
