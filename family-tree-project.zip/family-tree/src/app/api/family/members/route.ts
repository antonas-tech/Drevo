import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getAuthUser } from '@/lib/auth'
import { ok, err, unauthorized, serverError } from '@/lib/api'
import { z } from 'zod'

export async function GET() {
  try {
    const members = await prisma.familyMember.findMany({
      include: {
        relationsA: {
          include: { memberB: true }
        },
        relationsB: {
          include: { memberA: true }
        },
        armyRecord: true,
      },
      orderBy: [{ generation: 'asc' }, { birthDate: 'asc' }]
    })

    return ok(members)
  } catch (e) {
    return serverError(e)
  }
}

const memberSchema = z.object({
  firstName: z.string().min(1, 'Имя обязательно').max(50),
  lastName: z.string().min(1, 'Фамилия обязательна').max(50),
  maidenName: z.string().max(50).optional(),
  middleName: z.string().max(50).optional(),
  gender: z.enum(['MALE', 'FEMALE', 'OTHER', 'UNKNOWN']).optional(),
  birthDate: z.string().optional().nullable(),
  deathDate: z.string().optional().nullable(),
  birthPlace: z.string().max(200).optional(),
  biography: z.string().max(5000).optional(),
  profession: z.string().max(200).optional(),
  isAlive: z.boolean().optional(),
  isMemorial: z.boolean().optional(),
  memorialText: z.string().max(2000).optional(),
  generation: z.number().int().optional(),
  posX: z.number().optional(),
  posY: z.number().optional(),
  awards: z.array(z.string()).optional(),
  cities: z.array(z.string()).optional(),
})

export async function POST(request: NextRequest) {
  const user = await getAuthUser(request)
  if (!user) return unauthorized()

  try {
    const body = await request.json()
    const parsed = memberSchema.safeParse(body)
    if (!parsed.success) return err(parsed.error.errors[0].message)

    const data = parsed.data
    const member = await prisma.familyMember.create({
      data: {
        ...data,
        birthDate: data.birthDate ? new Date(data.birthDate) : null,
        deathDate: data.deathDate ? new Date(data.deathDate) : null,
        gender: data.gender || 'UNKNOWN',
        awards: data.awards || [],
        cities: data.cities || [],
      }
    })

    return ok(member, 201)
  } catch (e) {
    return serverError(e)
  }
}
