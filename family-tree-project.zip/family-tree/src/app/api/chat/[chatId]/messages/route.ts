import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getAuthUser } from '@/lib/auth'
import { ok, err, unauthorized, forbidden, serverError } from '@/lib/api'

export async function GET(request: NextRequest, { params }: { params: { chatId: string } }) {
  const user = await getAuthUser(request)
  if (!user) return unauthorized()

  try {
    // Check membership
    const membership = await prisma.chatMember.findUnique({
      where: { chatId_userId: { chatId: params.chatId, userId: user.id } }
    })
    if (!membership) return forbidden()

    const { searchParams } = new URL(request.url)
    const cursor = searchParams.get('cursor')
    const limit = 30

    const messages = await prisma.message.findMany({
      where: {
        chatId: params.chatId,
        isDeleted: false,
        ...(cursor ? { createdAt: { lt: new Date(cursor) } } : {})
      },
      include: {
        sender: {
          select: { id: true, username: true, profile: { select: { avatar: true } } }
        },
        reactions: true,
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
    })

    // Update last read
    await prisma.chatMember.update({
      where: { chatId_userId: { chatId: params.chatId, userId: user.id } },
      data: { lastReadAt: new Date() }
    })

    return ok({
      messages: messages.reverse(),
      hasMore: messages.length === limit,
      nextCursor: messages[0]?.createdAt.toISOString(),
    })
  } catch (e) {
    return serverError(e)
  }
}

export async function POST(request: NextRequest, { params }: { params: { chatId: string } }) {
  const user = await getAuthUser(request)
  if (!user) return unauthorized()

  try {
    const membership = await prisma.chatMember.findUnique({
      where: { chatId_userId: { chatId: params.chatId, userId: user.id } }
    })
    if (!membership) return forbidden()
    if (membership.isMuted) return err('Вы заглушены в этом чате', 403)

    const { content, type = 'TEXT', fileUrl } = await request.json()

    if (!content && !fileUrl) return err('Сообщение не может быть пустым')

    const message = await prisma.message.create({
      data: {
        chatId: params.chatId,
        senderId: user.id,
        content,
        type,
        fileUrl,
      },
      include: {
        sender: {
          select: { id: true, username: true, profile: { select: { avatar: true } } }
        },
      }
    })

    // Update chat updatedAt
    await prisma.chat.update({
      where: { id: params.chatId },
      data: { updatedAt: new Date() }
    })

    return ok(message, 201)
  } catch (e) {
    return serverError(e)
  }
}
