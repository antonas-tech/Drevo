import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getAuthUser } from '@/lib/auth'
import { ok, err, unauthorized, serverError } from '@/lib/api'

export async function GET(request: NextRequest) {
  const user = await getAuthUser(request)
  if (!user) return unauthorized()

  try {
    const chats = await prisma.chat.findMany({
      where: {
        members: { some: { userId: user.id } }
      },
      include: {
        members: {
          include: {
            user: { select: { id: true, username: true, lastSeenAt: true, profile: { select: { avatar: true } } } }
          }
        },
        messages: {
          take: 1,
          orderBy: { createdAt: 'desc' },
          include: {
            sender: { select: { username: true } }
          }
        },
        _count: { select: { messages: true } }
      },
      orderBy: { updatedAt: 'desc' }
    })

    return ok(chats)
  } catch (e) {
    return serverError(e)
  }
}

export async function POST(request: NextRequest) {
  const user = await getAuthUser(request)
  if (!user) return unauthorized()

  try {
    const { name, isGroup, memberIds } = await request.json()

    if (!memberIds || memberIds.length === 0) {
      return err('Укажите участников чата')
    }

    const allMemberIds = [...new Set([user.id, ...memberIds])]

    // Check for existing DM
    if (!isGroup && allMemberIds.length === 2) {
      const existing = await prisma.chat.findFirst({
        where: {
          isGroup: false,
          AND: allMemberIds.map(id => ({
            members: { some: { userId: id } }
          }))
        }
      })
      if (existing) return ok(existing)
    }

    const chat = await prisma.chat.create({
      data: {
        name: isGroup ? name : null,
        isGroup: isGroup || false,
        members: {
          create: allMemberIds.map((id, i) => ({
            userId: id,
            role: i === 0 ? 'admin' : 'member'
          }))
        }
      },
      include: {
        members: {
          include: {
            user: { select: { id: true, username: true, profile: { select: { avatar: true } } } }
          }
        }
      }
    })

    return ok(chat, 201)
  } catch (e) {
    return serverError(e)
  }
}
