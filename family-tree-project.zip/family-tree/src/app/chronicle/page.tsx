'use client'

import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Header } from '@/components/header'
import { formatDate, cn } from '@/lib/utils'
import { BookOpen, Tag, Calendar, User, Loader2 } from 'lucide-react'

interface Chronicle {
  id: string
  title: string
  content: string
  year?: number | null
  date?: string | null
  tags: string[]
  author?: string | null
  coverPhoto?: string | null
  isPublic: boolean
  createdAt: string
}

export default function ChroniclePage() {
  const [entries, setEntries] = useState<Chronicle[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/chronicle')
      .then(r => r.json())
      .then(d => { if (d.success) setEntries(d.data) })
      .finally(() => setLoading(false))
  }, [])

  return (
    <div className="min-h-screen">
      <Header />
      <div className="container py-10 max-w-3xl">
        <div className="mb-10">
          <h1 className="section-header mb-2 flex items-center gap-3">
            <BookOpen className="w-7 h-7 text-primary" />
            Летопись рода
          </h1>
          <p className="text-muted-foreground">
            История семьи, запечатлённая в событиях, датах и воспоминаниях поколений
          </p>
        </div>

        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : entries.length === 0 ? (
          <div className="text-center py-20 text-muted-foreground">
            <BookOpen className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p>Летопись ещё пуста</p>
          </div>
        ) : (
          <div className="relative">
            {/* Timeline line */}
            <div className="timeline-line" />

            <div className="space-y-8 pl-16">
              {entries.map((entry, i) => (
                <motion.div
                  key={entry.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: i * 0.1 }}
                  className="relative"
                >
                  {/* Timeline dot */}
                  <div className="timeline-dot" style={{ top: '1.25rem' }} />

                  <div className="card-premium p-6">
                    {/* Year badge */}
                    {entry.year && (
                      <div className="absolute -left-24 top-4 text-right">
                        <span className="font-display text-2xl font-bold text-amber-600/60">
                          {entry.year}
                        </span>
                      </div>
                    )}

                    <h2 className="font-display text-xl font-semibold mb-3">{entry.title}</h2>

                    <p className="text-muted-foreground leading-relaxed mb-4">{entry.content}</p>

                    <div className="flex items-center flex-wrap gap-3 text-xs text-muted-foreground">
                      {entry.author && (
                        <span className="flex items-center gap-1">
                          <User className="w-3 h-3" />
                          {entry.author}
                        </span>
                      )}
                      {entry.date && (
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {formatDate(entry.date, { year: 'numeric', month: 'long', day: 'numeric' })}
                        </span>
                      )}
                      {entry.tags.length > 0 && (
                        <div className="flex items-center gap-1">
                          <Tag className="w-3 h-3" />
                          {entry.tags.map(tag => (
                            <span key={tag} className="px-2 py-0.5 bg-accent rounded-full text-xs">
                              {tag}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
