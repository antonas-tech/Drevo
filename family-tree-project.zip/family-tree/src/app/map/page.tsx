'use client'

import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Header } from '@/components/header'
import { Map, MapPin, Users, Loader2 } from 'lucide-react'

interface FamilyMember {
  id: string
  firstName: string
  lastName: string
  birthPlace?: string | null
  cities: string[]
  generation?: number | null
  isAlive: boolean
}

function getCityStats(members: FamilyMember[]) {
  const stats: Record<string, { count: number; members: string[] }> = {}
  members.forEach(m => {
    const places = [
      ...(m.birthPlace ? [m.birthPlace.split(',')[0].trim()] : []),
      ...m.cities
    ]
    const unique = [...new Set(places)]
    unique.forEach(place => {
      if (!stats[place]) stats[place] = { count: 0, members: [] }
      stats[place].count++
      stats[place].members.push(`${m.firstName} ${m.lastName}`)
    })
  })
  return Object.entries(stats).sort(([, a], [, b]) => b.count - a.count)
}

export default function MapPage() {
  const [members, setMembers] = useState<FamilyMember[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedCity, setSelectedCity] = useState<string | null>(null)

  useEffect(() => {
    fetch('/api/family/members')
      .then(r => r.json())
      .then(d => { if (d.success) setMembers(d.data) })
      .finally(() => setLoading(false))
  }, [])

  const cityStats = getCityStats(members)

  const mapCities = [
    { name: 'Москва', x: 200, y: 130 },
    { name: 'Тула', x: 195, y: 150 },
    { name: 'Санкт-Петербург', x: 165, y: 100 },
    { name: 'Рязань', x: 225, y: 148 },
    { name: 'Ленинград', x: 165, y: 100 },
    { name: 'Подмосковье', x: 210, y: 135 },
  ]

  return (
    <div className="min-h-screen">
      <Header />
      <div className="container py-10">
        <div className="mb-10">
          <h1 className="section-header mb-2 flex items-center gap-3">
            <Map className="w-7 h-7 text-primary" />
            Карта семьи
          </h1>
          <p className="text-muted-foreground">
            Города и места, связанные с историей нашего рода
          </p>
        </div>

        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="grid lg:grid-cols-2 gap-8">
            {/* SVG Map */}
            <div className="card-premium p-6 rounded-2xl">
              <div className="aspect-[4/3] bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950/30 dark:to-blue-900/20 rounded-xl relative overflow-hidden">
                <svg viewBox="0 0 400 300" className="w-full h-full p-4">
                  {/* Background grid */}
                  <defs>
                    <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
                      <path d="M 20 0 L 0 0 0 20" fill="none" stroke="hsl(var(--border))" strokeWidth="0.5" opacity="0.5" />
                    </pattern>
                  </defs>
                  <rect width="400" height="300" fill="url(#grid)" />

                  {/* Decorative rivers */}
                  <path d="M150 50 Q170 80 160 120 Q150 160 170 200" stroke="#93c5fd" strokeWidth="2" fill="none" opacity="0.4" />
                  <path d="M200 80 Q220 100 210 140 Q200 180 220 220" stroke="#93c5fd" strokeWidth="1.5" fill="none" opacity="0.3" />

                  {/* Movement paths between cities */}
                  <path d="M165 100 Q180 115 195 130" stroke="hsl(var(--primary))" strokeWidth="1" fill="none" strokeDasharray="4 2" opacity="0.4" />
                  <path d="M195 130 Q195 140 195 150" stroke="hsl(var(--primary))" strokeWidth="1" fill="none" strokeDasharray="4 2" opacity="0.4" />
                  <path d="M225 148 Q210 140 200 130" stroke="hsl(var(--primary))" strokeWidth="1" fill="none" strokeDasharray="4 2" opacity="0.4" />

                  {/* City markers */}
                  {mapCities.map((city, i) => {
                    const cityData = cityStats.find(([name]) =>
                      name.toLowerCase() === city.name.toLowerCase() ||
                      city.name.toLowerCase().includes(name.toLowerCase().slice(0, 5))
                    )
                    const hasMembers = !!cityData
                    const count = cityData?.[1].count || 0
                    const isSelected = selectedCity === city.name

                    if (!hasMembers) return null

                    return (
                      <g
                        key={i}
                        className="cursor-pointer"
                        onClick={() => setSelectedCity(isSelected ? null : city.name)}
                      >
                        {/* Glow ring */}
                        {isSelected && (
                          <circle cx={city.x} cy={city.y} r={16} fill="hsl(var(--primary))" opacity="0.2" />
                        )}
                        <circle
                          cx={city.x}
                          cy={city.y}
                          r={Math.max(8, count * 4)}
                          fill="hsl(var(--primary))"
                          opacity={isSelected ? 1 : 0.7}
                          filter="drop-shadow(0 0 4px hsl(var(--primary)))"
                        />
                        <text
                          x={city.x}
                          y={city.y + 4}
                          textAnchor="middle"
                          fontSize="9"
                          fill="white"
                          fontWeight="bold"
                        >
                          {count}
                        </text>
                        <text
                          x={city.x + Math.max(8, count * 4) + 4}
                          y={city.y + 4}
                          fontSize="10"
                          className="fill-foreground"
                          fontWeight={isSelected ? 'bold' : 'normal'}
                        >
                          {city.name}
                        </text>
                      </g>
                    )
                  })}
                </svg>

                <div className="absolute bottom-3 left-3 text-xs text-muted-foreground bg-background/70 px-2 py-1 rounded">
                  Нажмите на город для подробностей
                </div>
              </div>

              {/* Legend */}
              <div className="mt-3 flex items-center gap-4 text-xs text-muted-foreground">
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-primary opacity-70" />
                  <span>Город присутствия</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-8 h-px border-dashed border border-primary opacity-50" />
                  <span>Переезды</span>
                </div>
              </div>
            </div>

            {/* City list */}
            <div className="space-y-4">
              <h2 className="font-semibold text-lg">Города нашей семьи</h2>

              {cityStats.length === 0 ? (
                <p className="text-muted-foreground text-sm">Нет данных о местах проживания</p>
              ) : (
                <div className="space-y-3">
                  {cityStats.map(([city, data], i) => (
                    <motion.div
                      key={city}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.4, delay: i * 0.05 }}
                      onClick={() => setSelectedCity(selectedCity === city ? null : city)}
                      className={`card-premium p-4 cursor-pointer transition-all ${
                        selectedCity === city ? 'border-primary/50 bg-primary/5' : 'hover:border-primary/30'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-lg bg-primary/10">
                          <MapPin className="w-4 h-4 text-primary" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-medium">{city}</h3>
                          {selectedCity === city && (
                            <motion.div
                              initial={{ height: 0 }}
                              animate={{ height: 'auto' }}
                              className="mt-2 overflow-hidden"
                            >
                              <div className="flex flex-wrap gap-1">
                                {data.members.map((name, j) => (
                                  <span key={j} className="px-2 py-0.5 bg-muted rounded text-xs">
                                    {name}
                                  </span>
                                ))}
                              </div>
                            </motion.div>
                          )}
                        </div>
                        <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                          <Users className="w-4 h-4" />
                          <span>{data.count}</span>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}

              {/* Summary stats */}
              <div className="card-premium p-4 bg-primary/5 border-primary/20">
                <h3 className="font-medium mb-3">Статистика</h3>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <p className="text-2xl font-bold text-primary">{cityStats.length}</p>
                    <p className="text-muted-foreground text-xs">Городов</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-primary">{members.length}</p>
                    <p className="text-muted-foreground text-xs">Членов семьи</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-primary">
                      {members.filter(m => m.isAlive).length}
                    </p>
                    <p className="text-muted-foreground text-xs">Живут сейчас</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-primary">
                      {[...new Set(members.flatMap(m => m.cities))].length}
                    </p>
                    <p className="text-muted-foreground text-xs">Уникальных мест</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
