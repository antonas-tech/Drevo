import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatDate(date: Date | string | null | undefined, opts?: Intl.DateTimeFormatOptions) {
  if (!date) return '—'
  return new Intl.DateTimeFormat('ru-RU', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    ...opts
  }).format(new Date(date))
}

export function formatYear(date: Date | string | null | undefined) {
  if (!date) return '?'
  return new Date(date).getFullYear().toString()
}

export function getAge(birthDate: Date | string | null | undefined, deathDate?: Date | string | null): string {
  if (!birthDate) return ''
  const start = new Date(birthDate)
  const end = deathDate ? new Date(deathDate) : new Date()
  const age = end.getFullYear() - start.getFullYear()
  return `${age} лет`
}

export function getInitials(firstName: string, lastName: string) {
  return `${firstName[0] || ''}${lastName[0] || ''}`.toUpperCase()
}

export function truncate(str: string, length: number) {
  if (str.length <= length) return str
  return str.slice(0, length) + '...'
}

export function debounce<T extends (...args: unknown[]) => unknown>(fn: T, delay: number) {
  let timer: NodeJS.Timeout
  return (...args: Parameters<T>) => {
    clearTimeout(timer)
    timer = setTimeout(() => fn(...args), delay)
  }
}
