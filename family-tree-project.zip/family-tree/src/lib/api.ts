import { NextResponse } from 'next/server'

export function ok<T>(data: T, status = 200) {
  return NextResponse.json({ success: true, data }, { status })
}

export function err(message: string, status = 400) {
  return NextResponse.json({ success: false, error: message }, { status })
}

export function unauthorized() {
  return err('Необходима авторизация', 401)
}

export function forbidden() {
  return err('Недостаточно прав', 403)
}

export function notFound(entity = 'Объект') {
  return err(`${entity} не найден`, 404)
}

export function serverError(error?: unknown) {
  console.error('Server error:', error)
  return err('Внутренняя ошибка сервера', 500)
}
