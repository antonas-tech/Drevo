'use client'

import { createContext, useContext, useEffect, useState, ReactNode } from 'react'
import { ThemeProvider } from 'next-themes'

interface User {
  id: string
  email: string
  username: string
  role: string
  profile?: {
    avatar?: string | null
    bio?: string | null
  } | null
}

interface AuthContextType {
  user: User | null
  token: string | null
  login: (token: string, user: User) => void
  logout: () => void
  isLoading: boolean
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  token: null,
  login: () => {},
  logout: () => {},
  isLoading: true,
})

export function useAuth() {
  return useContext(AuthContext)
}

function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [token, setToken] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const storedToken = localStorage.getItem('auth-token')
    const storedUser = localStorage.getItem('auth-user')
    if (storedToken && storedUser) {
      try {
        setToken(storedToken)
        setUser(JSON.parse(storedUser))
      } catch {}
    }
    setIsLoading(false)
  }, [])

  const login = (newToken: string, newUser: User) => {
    setToken(newToken)
    setUser(newUser)
    localStorage.setItem('auth-token', newToken)
    localStorage.setItem('auth-user', JSON.stringify(newUser))
    document.cookie = `auth-token=${newToken}; path=/; max-age=${7 * 24 * 3600}`
  }

  const logout = () => {
    setToken(null)
    setUser(null)
    localStorage.removeItem('auth-token')
    localStorage.removeItem('auth-user')
    document.cookie = 'auth-token=; path=/; max-age=0'
    window.location.href = '/login'
  }

  return (
    <AuthContext.Provider value={{ user, token, login, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  )
}

export function Providers({ children }: { children: ReactNode }) {
  return (
    <ThemeProvider
      attribute="class"
      defaultTheme="light"
      enableSystem
      disableTransitionOnChange={false}
    >
      <AuthProvider>
        {children}
      </AuthProvider>
    </ThemeProvider>
  )
}
