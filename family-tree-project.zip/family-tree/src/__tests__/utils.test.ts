import { formatYear, getAge, getInitials, truncate } from '../lib/utils'

describe('formatYear', () => {
  it('returns year from date string', () => {
    expect(formatYear('1990-05-15')).toBe('1990')
  })
  it('returns ? for null', () => {
    expect(formatYear(null)).toBe('?')
  })
})

describe('getAge', () => {
  it('calculates age correctly', () => {
    const result = getAge('1950-01-01', '2020-01-01')
    expect(result).toBe('70 лет')
  })
})

describe('getInitials', () => {
  it('returns initials', () => {
    expect(getInitials('Иван', 'Иванов')).toBe('ИИ')
  })
})

describe('truncate', () => {
  it('truncates long strings', () => {
    expect(truncate('Hello World', 5)).toBe('Hello...')
  })
  it('does not truncate short strings', () => {
    expect(truncate('Hi', 5)).toBe('Hi')
  })
})
