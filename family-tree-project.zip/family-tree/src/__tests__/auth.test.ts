import { verifyToken, signToken } from '../lib/auth'

describe('JWT utils', () => {
  const payload = { userId: 'test-id', email: 'test@test.com', role: 'USER' }

  it('signs and verifies token', () => {
    const token = signToken(payload)
    expect(token).toBeTruthy()
    const decoded = verifyToken(token)
    expect(decoded?.userId).toBe(payload.userId)
    expect(decoded?.email).toBe(payload.email)
  })

  it('returns null for invalid token', () => {
    expect(verifyToken('invalid-token')).toBeNull()
    expect(verifyToken('')).toBeNull()
  })
})
